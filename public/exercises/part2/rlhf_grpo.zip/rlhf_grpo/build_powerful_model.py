#!/usr/bin/env python
"""Build the chatbot checkpoint used by cx_RLHF_GRPO_{solutions,students}.ipynb.

A short SFT pass of the base model Qwen2.5-1.5B (pretrained only, never instruction-tuned) on a few thousand
generic instruction examples from Dolly, unrelated to the refusal task, so that the result answers like a chatbot
and nothing more: it has never seen our prompts and has never been taught when to refuse.

    python build_powerful_model.py                       # writes ./powerful_model_1.5b
    python build_powerful_model.py --out /path/to/folder

Needs one GPU with about 40 GB free (float32 weights, gradients and Adam state for 1.5B parameters).
"""
import argparse
import gc
import os
import random
import time
import urllib.request

import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

BASE_MODEL = "Qwen/Qwen2.5-1.5B"
CHAT_SYSTEM_PROMPT = "You are a helpful assistant."      # must match the notebook: the checkpoint learns this layout
SFT_DATA_URL = "https://huggingface.co/datasets/databricks/databricks-dolly-15k/resolve/main/databricks-dolly-15k.jsonl"


def seed_everything(seed=0):
    '''Fix every random number generator we use (Python, NumPy, torch on CPU and GPU).'''
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="powerful_model_1.5b", help="output folder (default: %(default)s)")
    ap.add_argument("--base", default=BASE_MODEL, help="base model, Hub id or local folder (default: %(default)s)")
    ap.add_argument("--data", default="databricks-dolly-15k.jsonl", help="Dolly jsonl, downloaded if missing")
    ap.add_argument("--examples", type=int, default=3000, help="number of SFT examples (default: %(default)s)")
    ap.add_argument("--epochs", type=int, default=3, help="passes over the examples (default: %(default)s)")
    ap.add_argument("--batch", type=int, default=8, help="examples per optimiser step (default: %(default)s)")
    ap.add_argument("--lr", type=float, default=1e-5, help="learning rate (default: %(default)s)")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    if os.path.exists(args.out):
        raise SystemExit(f"{args.out} already exists; remove it or pass --out to build somewhere else")
    if not torch.cuda.is_available():
        raise SystemExit("no GPU found: this script trains a 1.5B model and needs one")
    device = "cuda"
    # PyTorch's cuDNN attention kernel returns nan gradients on the GH200 for some padded batches (step 104 of
    # this build, Santis, 2026-10-18), and one step later every weight is nan. The other kernels are fine.
    torch.backends.cuda.enable_cudnn_sdp(False)

    # ── Tokenizer and the chat layout, exactly as in the notebook ────────────────────────────────────────────
    tokenizer = AutoTokenizer.from_pretrained(args.base)
    end_id = tokenizer.convert_tokens_to_ids("<|im_end|>")

    def format_prompt(prompt):
        '''One user message in Qwen's chat layout, ending with an open assistant turn.'''
        messages = [{"role": "system", "content": CHAT_SYSTEM_PROMPT},
                    {"role": "user",   "content": prompt}]
        return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

    def encode(prompt, answer):
        '''Token ids of prompt + answer + <|im_end|>, and the number P of prompt tokens.'''
        prompt_ids = tokenizer(format_prompt(prompt))["input_ids"]
        answer_ids = tokenizer(answer)["input_ids"] + [end_id]
        return prompt_ids + answer_ids, len(prompt_ids)

    def batch_encode(prompts, answers):
        '''Right-padded ids [B, T], attention mask [B, T], answer mask [B, T] (1 on the answer tokens).'''
        encoded = [encode(p, a) for p, a in zip(prompts, answers)]
        T = max(len(seq) for seq, _ in encoded)
        ids  = torch.full((len(encoded), T), tokenizer.pad_token_id)
        attn = torch.zeros((len(encoded), T), dtype=torch.long)
        ans  = torch.zeros((len(encoded), T))
        for b, (seq, P) in enumerate(encoded):
            ids[b, :len(seq)]  = torch.tensor(seq)
            attn[b, :len(seq)] = 1
            ans[b, P:len(seq)] = 1
        return ids.to(device), attn.to(device), ans.to(device)

    # ── Data: self-contained, answer-sized Dolly examples ────────────────────────────────────────────────────
    if not os.path.exists(args.data):
        print("downloading", SFT_DATA_URL)
        urllib.request.urlretrieve(SFT_DATA_URL, args.data)
    dolly = pd.read_json(args.data, lines=True)
    dolly = dolly[(dolly.context == "") & dolly.response.str.split().str.len().between(10, 120)]
    sft_set = dolly.sample(n=args.examples, random_state=args.seed)
    prompts, answers = sft_set.instruction.tolist(), sft_set.response.tolist()
    print(len(prompts), "SFT examples, e.g.:", repr(prompts[0]), "->", repr(answers[0][:80]))

    # ── SFT: mean negative log-likelihood per answer token ───────────────────────────────────────────────────
    seed_everything(args.seed)
    model = AutoModelForCausalLM.from_pretrained(args.base, dtype=torch.float32).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.0)
    g = torch.Generator().manual_seed(args.seed)
    t0 = time.perf_counter()
    for epoch in range(args.epochs):
        order = torch.randperm(len(answers), generator=g).tolist()
        for b in range(0, len(order), args.batch):
            idx = order[b:b + args.batch]
            ids, attn, ans = batch_encode([prompts[i] for i in idx], [answers[i] for i in idx])
            with torch.autocast("cuda", dtype=torch.bfloat16):
                logits = model(input_ids=ids, attention_mask=attn).logits
            token_logp = torch.log_softmax(logits[:, :-1].float(), -1).gather(-1, ids[:, 1:, None]).squeeze(-1)
            loss = -(token_logp * ans[:, 1:]).sum() / ans[:, 1:].sum()
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        print(f"SFT epoch {epoch} | nll/token {loss.item():.2f} | {time.perf_counter() - t0:.0f} s")

    model.save_pretrained(args.out)
    tokenizer.save_pretrained(args.out)
    print("saved", args.out)
    del model, optimizer
    gc.collect(); torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
