"""Helpers for cx_RLHF_GRPO_{solutions,students}.ipynb that are not part of the lesson: the HTML cards that show answers.

Same card layout as rl_utils.py (the RLHF part of this exercise), in shades of blue. A right answer gets a filled dark
badge and a wrong one an outlined grey badge, each with a tick or a cross, so the difference never rests on colour
alone. Nothing here is an exercise; the notebook keeps everything it teaches.
"""
import html
import re

from IPython.display import HTML, display

NAVY, BLUE, SKY, ICE = "#1e3a8a", "#2563eb", "#dbeafe", "#eff6ff"   # titles and right badge / accent / highlight / header
SLATE, LINE = "#64748b", "#c7d7f5"                                 # wrong badge and secondary text / borders
FONT = "system-ui, 'Segoe UI', Roboto, sans-serif"

# Where the grader looks, highlighted in the answer text (matched after HTML escaping): the <answer> tags of our prompt.
_GRADED = re.compile(r"(&lt;answer&gt;.*?&lt;/answer&gt;)", re.S)


def tag_number(text):
    """The number inside the first <answer>...</answer> pair: the same rule as extract_answer in the notebook.

    Args:
        text: one completion, the prompt stripped.

    Returns:
        The number as a float, or None when there is no closed pair or no number inside it.
    """
    m = re.search(r"<answer>(.*?)</answer>", text, re.S)
    nums = re.findall(r"-?\d[\d,]*\.?\d*", m.group(1)) if m else []
    return float(nums[0].replace(",", "")) if nums else None


def _pill(text, filled):
    style = (f"background:{NAVY};color:white;border:1px solid {NAVY}" if filled
             else f"background:white;color:{SLATE};border:1px solid {SLATE}")
    return f'<span style="{style};border-radius:999px;padding:1px 9px;white-space:nowrap">{text}</span>'


def _verdict(pred, gold):
    if pred is None:
        return _pill("✗ no answer read", filled=False)
    return _pill(f"✓ correct · {pred:g}", filled=True) if pred == gold else _pill(f"✗ wrong · {pred:g}", filled=False)


def _body(text):
    mark = f"background:{SKY};color:{NAVY};border-radius:4px;padding:0 3px;font-weight:600"
    return _GRADED.sub(lambda m: f'<mark style="{mark}">{m.group(1)}</mark>', html.escape(text))


def show_answers(question, answers, gold, labels=None, read=tag_number):
    """One card: the question and its gold answer on top, then every answer with the number read from it and its grade.

    Answers sit two per row, one per row when the JupyterLab pane is narrow; a long answer scrolls inside its box. When
    several answers come with the default labels they are samples of one model, and the header counts how many are right.

    Args:
        question: the question text, as in the dataset.
        answers: one completion (a string) or a list of them, prompts stripped.
        gold: the gold answer.
        labels: one title per answer. Default: "answer" for a single one, "sample 1", "sample 2", ... for several.
        read: the function that reads the graded number from a completion. Default: the number inside the tags.
    """
    answers = [answers] if isinstance(answers, str) else list(answers)
    samples = labels is None and len(answers) > 1
    labels = labels or (["answer"] if len(answers) == 1 else [f"sample {k + 1}" for k in range(len(answers))])
    preds = [read(a) for a in answers]
    tally = f" · {sum(p == gold for p in preds)}/{len(answers)} correct" if samples else ""

    columns = "".join(
        f'<div style="flex:1 1 45%;min-width:300px;background:white;padding:10px 12px">'
        f'<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:6px;font-size:0.8em">'
        f'<span style="color:{NAVY};font-weight:600;letter-spacing:0.05em">{html.escape(label).upper()}</span>'
        f'{_verdict(pred, gold)}</div>'
        f'<div style="white-space:pre-wrap;line-height:1.45;font-size:0.92em;max-height:26em;overflow-y:auto">'
        f'{_body(text)}</div></div>'
        for label, text, pred in zip(labels, answers, preds))
    # mathjax_ignore / tex2jax_ignore: the questions are full of dollar amounts, which JupyterLab would typeset as maths
    display(HTML(
        f'<div class="tex2jax_ignore mathjax_ignore" style="font-family:{FONT};margin:10px 0;border:1px solid {LINE};'
        f'border-radius:12px;overflow:hidden;color:#1f2937;background:white">'
        f'<div style="background:{ICE};padding:8px 12px;display:flex;gap:10px;align-items:baseline;flex-wrap:wrap">'
        f'<span style="background:{BLUE};color:white;border-radius:999px;padding:2px 10px;font-size:0.75em;'
        f'letter-spacing:0.05em">QUESTION</span>'
        f'<b style="flex:1 1 300px">{html.escape(question)}</b>'
        f'<span style="font-size:0.9em;color:{NAVY};white-space:nowrap">gold '
        f'<b style="border:1px solid {NAVY};border-radius:6px;padding:0 6px">{gold}</b>{tally}</span></div>'
        f'<div style="display:flex;flex-wrap:wrap;gap:1px;background:{LINE};border-top:1px solid {LINE}">{columns}</div>'
        f'</div>'))
