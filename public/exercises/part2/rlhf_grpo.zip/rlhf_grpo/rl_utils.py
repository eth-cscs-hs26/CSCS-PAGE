"""Helpers for cx_RLHF_GRPO_{solutions,students}.ipynb that are not part of the lesson.

Seeding, the HTML cards that display pairs and answers, the batched scoring of held-out pairs, and the interactive
widget used to try to fool the reward model. Nothing here is an exercise; the notebook keeps everything it teaches.
"""
import html
import random

import numpy as np
import pandas as pd
import torch
from IPython.display import HTML, display

SEED = 0
CLASS_COLOURS = {"villain": ("#b91c1c", "#fee2e2"), "lookalike": ("#047857", "#d1fae5")}   # red: should refuse; green: should help
_DEFAULT_COLOURS = ("#374151", "#f3f4f6")


def seed_everything(seed=SEED):
    '''Fix every random number generator we use (Python, NumPy, torch on CPU and GPU), so that a rerun gives the same numbers.'''
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)


# ── Cards ─────────────────────────────────────────────────────────────────────────────────────────────────────
def _card(cls, prompt, body, border_bg="white"):
    fg, bg = CLASS_COLOURS.get(cls, _DEFAULT_COLOURS)
    return (f'<div style="font-family:sans-serif;margin:10px 0;border:1px solid {fg};border-radius:10px;overflow:hidden;color:#222;background:{border_bg}">'
            f'<div style="background:{bg};padding:8px 12px;display:flex;gap:10px;align-items:baseline">'
            f'<span style="background:{fg};color:white;border-radius:999px;padding:2px 10px;font-size:0.8em;letter-spacing:0.05em">{cls.upper()}</span>'
            f'<b>{html.escape(prompt)}</b></div>' + body + '</div>')


def pair_card(row):
    '''One preference pair as an HTML card: the prompt on top, the chosen answer (✅) and the rejected one (❌) below.'''
    answer = lambda mark, label, text: (f'<div style="display:flex;gap:10px;padding:8px 12px;border-top:1px solid #eee;line-height:1.4">'
                                        f'<div style="min-width:1.5em;font-size:1.1em">{mark}</div>'
                                        f'<div><span style="font-size:0.8em;color:#666">{label}</span><br>{html.escape(text)}</div></div>')
    return _card(row.cls, row.prompt, answer("✅", "chosen", row.chosen) + answer("❌", "rejected", row.rejected))


def answer_card(cls, prompt, answer):
    '''One answer as an HTML card: a coloured class badge and the prompt on top, the answer below with its line breaks kept.'''
    return _card(cls, prompt, f'<div style="padding:10px 12px;white-space:pre-wrap;background:white;line-height:1.4">{html.escape(answer)}</div>')


def compare_card(cls, prompt, before_text, after_text):
    '''One prompt as a card with two columns: the reference model's answer on the left, the trained policy's on the right.'''
    fg, _ = CLASS_COLOURS.get(cls, _DEFAULT_COLOURS)
    column = lambda title, text: (f'<div style="flex:1;min-width:0"><div style="font-size:0.8em;color:{fg};font-weight:bold;'
                                  f'margin-bottom:4px">{title}</div><div style="white-space:pre-wrap;line-height:1.4">{html.escape(text)}</div></div>')
    return _card(cls, prompt, '<div style="display:flex;gap:16px;padding:10px 12px;background:white">'
                 + column("BEFORE (reference model)", before_text) + column("AFTER (DPO policy)", after_text) + '</div>')


def show_pairs(pref, per_class=2, classes=("villain", "lookalike")):
    '''The first `per_class` distinct prompts of each class in `pref`, each as a card with its chosen and rejected answer.'''
    display(HTML("".join(pair_card(pref[pref.cls == c].drop_duplicates("prompt").iloc[k])
                         for c in classes for k in range(per_class))))


def show_answers(m, pairs, reply, per_class=3, classes=("villain", "lookalike")):
    '''Greedy answers of model m (generated with the notebook's `reply`) to the first `per_class` distinct prompts of each class.'''
    demo = pd.concat([pairs[pairs.cls == c].drop_duplicates("prompt").iloc[:per_class] for c in classes])
    answers = reply(m, demo.prompt.tolist())
    display(HTML("".join(answer_card(row.cls, row.prompt, text) for row, [text] in zip(demo.itertuples(), answers))))


def show_before_after(prompts, before, after):
    '''One two-column card per row of `prompts` (a DataFrame with cls and prompt): answer before training, answer after.'''
    display(HTML("".join(compare_card(row.cls, row.prompt, b, a) for row, b, a in zip(prompts.itertuples(), before, after))))


# ── Reward model helpers ──────────────────────────────────────────────────────────────────────────────────────
@torch.no_grad()
def reward_scores(rm, pairs, batch_encode, batch_size=8):
    '''Scores of the chosen and of the rejected answer of every pair: two tensors of shape [len(pairs)].'''
    rc, rr = [], []
    for b in range(0, len(pairs), batch_size):
        chunk = pairs.iloc[b:b + batch_size]
        rc.append(rm(*batch_encode(chunk.prompt.tolist(), chunk.chosen.tolist())[:2]))
        rr.append(rm(*batch_encode(chunk.prompt.tolist(), chunk.rejected.tolist())[:2]))
    return torch.cat(rc), torch.cat(rr)


def reward_playground(rm, batch_encode, prompt, candidates):
    '''Interactive ranking: score every candidate answer to `prompt` with the reward model, highest first.
    Edit the prompt, add candidates one at a time with "Add & score", or clear them all. `candidates` is updated in place.
    Without ipywidgets (the CSCS JupyterHub container has none) the same ranking is shown once: edit the cell and rerun.'''
    try:
        import ipywidgets as widgets
    except ImportError:
        widgets = None

    @torch.no_grad()
    def score_all(p, texts):
        ids, attn, _ = batch_encode([p] * len(texts), texts)
        return rm(ids, attn).tolist()

    def render(p, texts):
        ranked = sorted(zip(score_all(p, texts), texts), reverse=True)
        rows = [f"<div style='font-family:sans-serif;margin-bottom:10px'><b>Prompt:</b> {html.escape(p)}</div>"]
        for rank, (s, t) in enumerate(ranked):
            best, worst = rank == 0 and len(ranked) > 1, rank == len(ranked) - 1 and len(ranked) > 1
            badge = "🥇" if best else "👎" if worst else ""
            colour = "hsl(120,70%,45%)" if best else "hsl(0,70%,45%)" if worst else "#999"
            rows.append(f"""
            <div style="display:flex;align-items:center;gap:12px;margin:6px 0;padding:8px 12px;border-radius:8px;
                        border-left:6px solid {colour};background:#fafafa;color:#222">
              <div style="font-size:1.3em;min-width:1.6em;text-align:center">{badge}</div>
              <div style="font-weight:bold;min-width:4em;text-align:right;color:{colour}">{s:+.2f}</div>
              <div style="flex:1;font-family:sans-serif">{html.escape(t)}</div>
            </div>""")
        return "".join(rows)

    if widgets is None:
        display(HTML(render(prompt, candidates) if candidates else "<i>No candidates yet: add some to the list and rerun.</i>"))
        return

    prompt_box = widgets.Text(value=prompt, description="Prompt", continuous_update=False, layout=widgets.Layout(width="100%"))
    new_box    = widgets.Textarea(placeholder="Type a new candidate answer, then click Add…",
                                  layout=widgets.Layout(width="100%", height="70px"))
    add_btn    = widgets.Button(description="Add & score", button_style="success", icon="plus")
    clear_btn  = widgets.Button(description="Clear all", button_style="warning", icon="trash")
    out        = widgets.Output()

    def refresh(*_):
        with out:
            out.clear_output(wait=True)
            display(HTML(render(prompt_box.value, candidates) if candidates else "<i>No candidates yet — add one above.</i>"))

    def on_add(_):
        text = new_box.value.strip()
        if text and text not in candidates:
            candidates.append(text)
            new_box.value = ""
            refresh()

    add_btn.on_click(on_add)
    clear_btn.on_click(lambda _: (candidates.clear(), refresh()))
    prompt_box.observe(refresh, names="value")
    display(widgets.VBox([prompt_box, new_box, widgets.HBox([add_btn, clear_btn]), out]))
    refresh()
