# CX PyTorch with SLURM and SLT

**CSCS · Day 1 · 12:15–13:00 · 45 minutes**

Carlos has shown the training and SLURM pipeline. Your task is to submit a working
one-GPU job yourself, prove it ran correctly, then compare two weight-decay settings.
Start with `01_pytorch_slurm_student.ipynb` and follow its sections in order.

## Where to work

Keep all the files in this folder together. Open the notebook in the prepared JupyterLab
session for checks, plots and interpretation, and a **JupyterLab terminal** (File → New →
Terminal) for `sbatch`, `squeue` and `sacct`. In that terminal, move into this folder and run
`source cluster-env.sh` once: without it, the Slurm commands fail inside the JupyterLab
container. Google Colab is not a route to submit CSCS SLURM jobs.

The batch file uses the account, partition and uenv from Carlos's lecture. It requests
one node, one task and one GPU, with a five-minute limit. The training step is complete.
There is no dataset download; `train.py` creates the samples in memory. The code refuses
to train on a login node and checks that exactly one GPU is visible inside the job.

## Core run sequence

From this folder in the **JupyterLab terminal**:

```bash
source cluster-env.sh
mkdir -p logs
job1=$(sbatch --parsable submit.sbatch 128 0.0)
job1=${job1%%;*}
printf 'Baseline job ID: %s\n' "$job1"
squeue -j "$job1" -o '%.18i %.9T %.10M %.6D %R'
scontrol show job "$job1"
tail -n 20 "logs/cx-pytorch-${job1}.out"
tail -n 20 "logs/cx-pytorch-${job1}.err"
sacct -j "$job1" --format=JobID,State,ExitCode,Elapsed,AllocTRES
```

A job ID proves submission, not completion. A pending job may have no logs. If it remains
pending for two minutes, inspect the reason and ask an instructor rather than submitting
copies. Check both job and training-step accounting. Look for `COMPLETED`, exit code `0:0`,
a `FIRST_STEP` line with five `cuda:0` devices, and `runs/<JOB_ID>/summary.json`.

After the baseline finishes, write a prediction in the notebook. Keep width 128 and
change only weight decay:

```bash
job2=$(sbatch --parsable submit.sbatch 128 0.01)
job2=${job2%%;*}
printf 'Weight-decay job ID: %s\n' "$job2"
```

Repeat the status, log and accounting checks for `$job2`. Enter both IDs in the notebook,
which checks the saved results and plots the curves. Compare final training and validation
loss and accuracy, then write a short conclusion and limitation. The optional debugging
question needs no additional cluster job.

## What each job saves

```text
logs/cx-pytorch-<JOB_ID>.out    # epochs, FIRST_STEP devices, completion
logs/cx-pytorch-<JOB_ID>.err    # errors and warnings
runs/<JOB_ID>/config.json      # settings, seeds, host and GPU
runs/<JOB_ID>/metrics.csv      # train/validation metrics for each epoch
runs/<JOB_ID>/summary.json     # written only after successful completion
```

A failed run may
have partial files but no summary; keep its logs and submit a new job after fixing it.
