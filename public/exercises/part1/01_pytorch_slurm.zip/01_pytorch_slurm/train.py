"""Small single-GPU batch workload. Data and orchestration are supplied."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import socket
import sys
import time

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from learner import training_step


def make_data():
    """Offline two moons, adapted from WE7's toy classification task.

    Fixed, independent train/validation draws from the same distribution.
    Each split is balanced. No download, fitted preprocessing, or label leakage.
    """
    rng = np.random.default_rng(7)
    def split(n):
        half = n // 2
        angle = rng.uniform(0, np.pi, size=half)
        a = np.column_stack((np.cos(angle), np.sin(angle)))
        angle = rng.uniform(0, np.pi, size=half)
        b = np.column_stack((1 - np.cos(angle), 0.5 - np.sin(angle)))
        x = np.concatenate((a, b)) + rng.normal(0, 0.30, (n, 2))
        y = np.repeat([0, 1], half)
        order = rng.permutation(n)
        return torch.tensor(x[order], dtype=torch.float32), torch.tensor(y[order], dtype=torch.long)
    return split(256), split(1024)


def make_model(width):
    return nn.Sequential(nn.Linear(2, width), nn.ReLU(),
                         nn.Linear(width, width), nn.ReLU(), nn.Linear(width, 2))


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    total_loss, correct, count = 0.0, 0, 0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        logits = model(x)
        total_loss += nn.functional.cross_entropy(logits, y, reduction="sum").item()
        correct += (logits.argmax(1) == y).sum().item()
        count += len(y)
    return total_loss / count, correct / count


def choose_device(local_cpu_test=False):
    if local_cpu_test:
        if os.environ.get("SLURM_JOB_ID"):
            raise RuntimeError("CPU test mode is for an instructor laptop; use the GPU path in Slurm.")
        return torch.device("cpu")
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("No Slurm allocation. Submit submit.sbatch; do not train on a login node.")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable. Check the GPU request and the Python environment inside srun.")
    if torch.cuda.device_count() != 1:
        raise RuntimeError("Expected exactly one visible GPU. Check --ntasks=1 and --gpus-per-task=1 with the instructor.")
    return torch.device("cuda:0")


def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--width", type=int, default=128)
    p.add_argument("--epochs", type=int, default=40)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--lr", type=float, default=0.01)
    p.add_argument("--weight-decay", type=float, default=0.0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--local-cpu-test", action="store_true", help="Instructor laptop testing only; never use on a login node")
    args = p.parse_args(argv)
    if not (1 <= args.width <= 256 and 1 <= args.epochs <= 100 and 1 <= args.batch_size <= 256):
        p.error("Workshop bounds: width 1..256, epochs 1..100, batch-size 1..256")
    if not (math.isfinite(args.lr) and 0 < args.lr <= 1 and math.isfinite(args.weight_decay) and 0 <= args.weight_decay <= 1):
        p.error("lr must be in (0, 1]; weight-decay in [0, 1]")
    return args


def run(args):
    device = choose_device(args.local_cpu_test)
    torch.set_num_threads(1)
    torch.manual_seed(args.seed)
    train_data, val_data = make_data()
    digest = hashlib.sha256()
    for tensor in (*train_data, *val_data):
        digest.update(tensor.numpy().tobytes())
    generator = torch.Generator().manual_seed(args.seed)
    train_loader = DataLoader(TensorDataset(*train_data), batch_size=args.batch_size,
                              shuffle=True, generator=generator, num_workers=0)
    # Evaluate both splits AFTER each epoch, with the same weights and eval mode.
    train_eval = DataLoader(TensorDataset(*train_data), batch_size=256, num_workers=0)
    val_loader = DataLoader(TensorDataset(*val_data), batch_size=256, num_workers=0)
    model = make_model(args.width).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    loss_fn = nn.CrossEntropyLoss()
    args.output.mkdir(parents=True, exist_ok=False)  # Never mix or overwrite experiments.
    metadata = dict(vars(args), output=str(args.output.resolve()),
                    hostname=socket.gethostname(), job_id=os.environ.get("SLURM_JOB_ID"),
                    python=sys.version, torch=torch.__version__, numpy=np.__version__,
                    cuda_build=torch.version.cuda, device=str(device),
                    gpu_name=torch.cuda.get_device_name(0) if device.type == "cuda" else None,
                    visible_devices=os.environ.get("CUDA_VISIBLE_DEVICES"),
                    visible_gpu_count=torch.cuda.device_count() if device.type == "cuda" else 0,
                    model_device=str(next(model.parameters()).device), data_sha256=digest.hexdigest(),
                    train_samples=256, val_samples=1024,
                    parameters=sum(p.numel() for p in model.parameters()))
    (args.output / "config.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata), flush=True)
    if device.type == "cuda":
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
    start = time.perf_counter()
    fields = ["epoch", "train_loss", "val_loss", "train_accuracy", "val_accuracy", "elapsed_seconds"]
    with (args.output / "metrics.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for epoch in range(1, args.epochs + 1):
            model.train()
            for batch in train_loader:
                loss, evidence = training_step(model, batch, optimizer, loss_fn, device)
                if epoch == 1 and "first_step" not in metadata:
                    metadata["first_step"] = evidence
                    print("FIRST_STEP " + json.dumps(evidence), flush=True)
                    (args.output / "config.json").write_text(json.dumps(metadata, indent=2) + "\n")
                if not math.isfinite(loss):
                    raise RuntimeError("Non-finite training loss; inspect the training step and learning rate.")
            tr_loss, tr_acc = evaluate(model, train_eval, device)
            va_loss, va_acc = evaluate(model, val_loader, device)
            if not all(math.isfinite(v) for v in (tr_loss, va_loss)):
                raise RuntimeError("Non-finite evaluation loss; inspect the training step and learning rate.")
            if device.type == "cuda":
                torch.cuda.synchronize()
            row = dict(zip(fields, (epoch, tr_loss, va_loss, tr_acc, va_acc, time.perf_counter() - start)))
            writer.writerow(row)
            f.flush()
            print(f"epoch={epoch:02d} train_loss={tr_loss:.4f} val_loss={va_loss:.4f} "
                  f"train_acc={tr_acc:.3f} val_acc={va_acc:.3f}", flush=True)
    summary = dict(row, status="completed", device=str(device),
                   peak_cuda_bytes=torch.cuda.max_memory_allocated() if device.type == "cuda" else 0)
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print("COMPLETED " + str(args.output.resolve()), flush=True)
    return summary


if __name__ == "__main__":
    run(parse_args())
