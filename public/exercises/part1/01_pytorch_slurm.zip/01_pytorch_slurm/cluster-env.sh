# Run once in each JupyterLab terminal, from this folder:  source cluster-env.sh
#
# Inside the JupyterLab container the Slurm commands miss one library (libjson-c.so.5),
# and sbatch would copy the container's environment into the job, which then starts
# inside the container again. These wrappers add the library from the course folder and
# give each command a clean environment, so the job runs on the compute node itself.
CX_SHARED=/capstor/scratch/cscs/course_00770/shared
cx_clean() { env -i HOME="$HOME" USER="$USER" PATH=/usr/bin:/bin LD_LIBRARY_PATH="$CX_SHARED" "$@"; }
sbatch()   { cx_clean sbatch "$@"; }
squeue()   { cx_clean squeue "$@"; }
scontrol() { cx_clean scontrol "$@"; }
sacct()    { cx_clean sacct "$@"; }
scancel()  { cx_clean scancel "$@"; }
echo "Slurm commands ready for this terminal."
