"""Completed training step from the lecture; supplied for the CX."""

def training_step(model, batch, optimizer, loss_fn, device):
    x, y = batch
    x, y = x.to(device), y.to(device)
    optimizer.zero_grad()
    logits = model(x)
    loss = loss_fn(logits, y)
    loss.backward()
    optimizer.step()
    evidence = {"model": str(next(model.parameters()).device),
                "features": str(x.device), "labels": str(y.device),
                "logits": str(logits.device), "loss": str(loss.device)}
    return loss.item(), evidence
