"""util.py -- the helpers behind the notebook "Train a language model from scratch".

Everything here is *plumbing*: the parts of a from-scratch LLM that are well understood,
tedious to retype, and not where the lesson lives.  The notebook keeps the pieces worth
writing yourself -- the BPE merge step, masked self-attention, the loss, the training
step, generation, the KV-cache decode step -- and imports the rest from here:

    hardware    detect the device and name it
    tokeniser   byte-level BPE: pre-tokenisation, the training loop, encode/decode
    model       a Llama-style decoder: RMSNorm, RoPE, SwiGLU, the block, the GPT
    training    batches, learning-rate schedule, the training loop, timing
    inference   the KV cache and generation benchmarks
    scoreboard  every measurement, saved per device and compared across machines
    data        ensure_data(): find data/, or rebuild it from the public TinyStories

Nothing here needs an API key or a CSCS account.  It runs on a laptop CPU, a laptop GPU
and a GH200, and measures whatever it is given.
"""

from __future__ import annotations

import json
import math
import os
import platform
import re
import subprocess
import time
from collections import Counter
from dataclasses import dataclass, field, asdict
from typing import Callable, Iterable, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 42

# On Hopper, scaled_dot_product_attention tries cuDNN's attention kernel first, and on
# Santis that fails to load a cuDNN sub-library (libcudnn_engines_runtime_compiled).
# With cuDNN off it uses PyTorch's own FlashAttention kernel, the one Part 3 describes.
torch.backends.cuda.enable_cudnn_sdp(False)

# ═══════════════════════════════════════════════════════════════════════════════
# 1. HARDWARE
# ═══════════════════════════════════════════════════════════════════════════════

# Published vendor peak numbers, dense BF16 tensor-core throughput and HBM
# bandwidth.  These are *spec sheet* figures: no real kernel reaches them.  We keep
# them only so a participant can see how far a real training step lands from the
# number on the brochure.  Everything else in this notebook is measured live.
PUBLISHED_PEAK_BF16_TFLOPS = {
    "GH200": 989.0,   # Hopper H100 die, dense BF16 (with sparsity the sheet says 2x)
    "H100": 989.0,
    "H200": 989.0,
    "A100": 312.0,
    "V100": 125.0,    # FP16; Volta has no BF16
}


@dataclass
class Hardware:
    """What we are actually running on, and what it can actually do."""

    device: str                      # "cuda" or "cpu"
    name: str                        # marketing name of the chip
    is_gh200: bool
    n_cores: int                     # host CPU cores visible to this process
    hbm_gb: float | None             # GPU memory, None on CPU
    sm_count: int | None
    bf16_ok: bool
    published_peak_tflops: float | None = None
    cpu_name: str = ""                           # the host CPU, whatever the device

    @property
    def short(self) -> str:
        return "GH200" if self.is_gh200 else self.name

    def summary(self) -> str:
        if self.device == "cpu":
            return f"CPU only — {self.name}, {self.n_cores} cores visible"
        bits = [f"GPU — {self.name}", f"{self.hbm_gb:.0f} GB GPU memory", f"{self.sm_count} SMs",
                f"host: {self.n_cores} CPU cores"]
        return " · ".join(bits)


def cpu_name() -> str:
    """The host CPU's model name, as the operating system reports it.

    Linux x86 says it in /proc/cpuinfo; Linux Arm (the Grace CPU in a GH200) only
    says it through lscpu, as "Neoverse-V2"; macOS through sysctl.  Used to label
    every CPU measurement, so a results file says what it was measured on.
    """
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
    except OSError:
        pass
    for cmd in (["lscpu"], ["sysctl", "-n", "machdep.cpu.brand_string"]):
        try:
            out = subprocess.run(cmd, capture_output=True, text=True, timeout=5).stdout
        except (OSError, subprocess.SubprocessError):
            continue
        if cmd[0] == "sysctl" and out.strip():
            return out.strip()
        for line in out.splitlines():
            if line.startswith("Model name:"):
                name = line.split(":", 1)[1].strip()
                return f"NVIDIA Grace ({name})" if "Neoverse-V2" in name else name
    return platform.processor() or platform.machine()


def detect_hardware() -> Hardware:
    """Look at the machine we were given.  No assumptions, no hard-coded node type."""
    n_cores = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 1)
    host_cpu = cpu_name()
    if not torch.cuda.is_available():
        return Hardware(device="cpu", name=host_cpu, is_gh200=False, n_cores=n_cores,
                        hbm_gb=None, sm_count=None, bf16_ok=False, cpu_name=host_cpu)
    p = torch.cuda.get_device_properties(0)
    name = p.name
    is_gh200 = "GH200" in name.upper() or "GRACE" in name.upper()
    # Match on a word boundary: "RTX A1000" must not be read as an A100.
    up = name.upper()
    key = next((k for k in PUBLISHED_PEAK_BF16_TFLOPS
                if re.search(rf"(?<![A-Z0-9]){re.escape(k)}(?![0-9])", up)), None)
    return Hardware(
        device="cuda", name=name, is_gh200=is_gh200, n_cores=n_cores,
        hbm_gb=p.total_memory / 1e9, sm_count=p.multi_processor_count,
        bf16_ok=torch.cuda.is_bf16_supported(),
        published_peak_tflops=PUBLISHED_PEAK_BF16_TFLOPS.get(key), cpu_name=host_cpu,
    )


def sync(device: str) -> None:
    """Wait for the GPU.  CUDA kernels are asynchronous: without this, every timing
    you take measures how fast Python can queue work, not how fast the GPU does it.
    This one line is the most common bug in home-made benchmarks."""
    if device == "cuda":
        torch.cuda.synchronize()


# ═══════════════════════════════════════════════════════════════════════════════
# 2. HELPERS AND HOUSE STYLE
# ═══════════════════════════════════════════════════════════════════════════════

PURPLE, PURPLE2 = "#667eea", "#764ba2"
GREEN, RED, AMBER = "#39b36a", "#e0796d", "#e0a23c"
GRAY = "#9aa3b2"


def install_house_style() -> None:
    """Matplotlib defaults used by every plot in the exercise."""
    import matplotlib.pyplot as plt

    plt.rcParams.update({
        "figure.dpi": 110, "font.size": 9,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.grid": True, "grid.alpha": 0.25,
        "axes.prop_cycle": plt.cycler(color=[PURPLE, GREEN, AMBER, RED, GRAY, PURPLE2]),
    })


def must_fill(**kwargs) -> None:
    """Stop with a readable message if an exercise cell still contains `...`.

    Call it straight after any cell whose result later cells depend on, so a missed
    exercise fails here with a sentence instead of three cells later with a
    traceback.
    """
    missing = [k for k, v in kwargs.items() if v is Ellipsis or v is None]
    if missing:
        raise ValueError(
            f"Please fill in {', '.join(missing)} in the cell above, then re-run this cell."
        )


def compare(label: str, guess, actual, fmt: str = "{:,.1f}") -> None:
    """Print a prediction next to the truth, so being wrong is informative."""
    try:
        g = fmt.format(guess)
    except (TypeError, ValueError):
        g = str(guess)
    a = fmt.format(actual)
    if isinstance(guess, (int, float)) and actual:
        ratio = actual / guess if guess else float("inf")
        verdict = "spot on" if 0.67 < ratio < 1.5 else f"off by {ratio:.1f}x" if ratio > 1 else f"off by {1/ratio:.1f}x"
        print(f"{label}\n    you guessed : {g}\n    reality     : {a}   ({verdict})")
    else:
        print(f"{label}\n    you guessed : {g}\n    reality     : {a}")


def set_seed(seed: int = SEED) -> None:
    import random

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ═══════════════════════════════════════════════════════════════════════════════
# 3. TOKENISER — byte-level BPE
# ═══════════════════════════════════════════════════════════════════════════════

END_OF_TEXT = "<|endoftext|>"

# GPT-2's pre-tokenisation pattern (the one CS336 and the 09:00 lecture use), written
# for the standard-library `re`: its Unicode classes \p{L} and \p{N} become [^\W\d_]
# (any letter) and \d.  Pre-tokenisation is what stops a merge from ever spanning a
# space, which is why BPE vocabularies contain " the" but never "the cat"; the space is
# glued to the FRONT of the next word.
_PRETOKEN_RE = re.compile(
    r"'(?:[sdmt]|ll|ve|re)| ?[^\W\d_]+| ?\d+| ?[^\s\w]+|\s+(?!\S)|\s+|_+"
)


def pretokenize(text: str) -> list[str]:
    """Split raw text into the chunks BPE is allowed to merge inside."""
    return _PRETOKEN_RE.findall(text)


def word_frequencies(text: str) -> dict[tuple[int, ...], int]:
    """Count pre-tokens, each represented as a tuple of raw byte values.

    Training BPE on the *word counts* rather than on the raw character stream is the
    one optimisation that makes it tractable: "the" appears 400,000 times in our
    corpus but is merged once, not 400,000 times.

    Returns:
        Mapping from a tuple of token ids (initially byte values 0-255) to how often
        that pre-token occurs in the text.
    """
    # The end-of-text marker separates stories and is a token of its own: split on it
    # first, so that no merge is ever learned from its characters.
    counts = Counter()
    for doc in text.split(END_OF_TEXT):
        counts.update(pretokenize(doc))
    return {tuple(w.encode("utf-8")): c for w, c in counts.items()}


def train_bpe(
    text: str,
    vocab_size: int,
    count_pairs_fn: Callable[[dict], Counter],
    merge_pair_fn: Callable[[dict, tuple[int, int], int], dict],
    special_tokens: Sequence[str] = (END_OF_TEXT,),
    log_every: int = 0,
) -> tuple[dict[int, bytes], list[tuple[int, int]]]:
    """Train a byte-level BPE vocabulary.

    The outer loop is provided; the two functions that do the work are the
    participant's (Exercise 1).  Repeat `vocab_size - 256 - len(specials)` times:
    count every adjacent pair, take the most frequent, give it a fresh id.

    Args:
        text: training corpus.
        vocab_size: target vocabulary size, including the 256 byte tokens and specials.
        count_pairs_fn: maps word_freqs -> Counter of adjacent-pair counts.
        merge_pair_fn: maps (word_freqs, pair, new_id) -> rewritten word_freqs.
        special_tokens: reserved strings that get their own ids and never merge.
        log_every: print progress every N merges (0 = silent).

    Returns:
        (vocab, merges) where vocab maps id -> bytes and merges is the ordered list
        of merged pairs.  The order matters: encoding replays it exactly.
    """
    vocab: dict[int, bytes] = {i: bytes([i]) for i in range(256)}
    for i, tok in enumerate(special_tokens):
        vocab[256 + i] = tok.encode("utf-8")
    next_id = 256 + len(special_tokens)

    wf = word_frequencies(text)
    merges: list[tuple[int, int]] = []
    t0 = time.perf_counter()
    while next_id < vocab_size:
        pair_counts = count_pairs_fn(wf)
        if not pair_counts:
            break
        # Ties: the greater pair wins, comparing the first token and then the second
        # (the rule of the 09:00 lecture and of CS336). It decides, for instance, that
        # "se" + "a" beats "s" + "he" in the lecture's toy example.
        best = max(pair_counts.items(), key=lambda kv: (kv[1], vocab[kv[0][0]], vocab[kv[0][1]]))[0]
        vocab[next_id] = vocab[best[0]] + vocab[best[1]]
        wf = merge_pair_fn(wf, best, next_id)
        merges.append(best)
        next_id += 1
        if log_every and len(merges) % log_every == 0:
            print(f"    {len(merges):5d} merges  {time.perf_counter()-t0:5.1f}s  "
                  f"newest: {vocab[next_id-1]!r}")
    return vocab, merges


class Tokenizer:
    """Encode text to ids and back, replaying a trained merge list."""

    def __init__(self, vocab: dict[int, bytes], merges: list[tuple[int, int]],
                 special_tokens: Sequence[str] = (END_OF_TEXT,)):
        self.vocab = vocab
        self.merges = merges
        self.ranks = {pair: i for i, pair in enumerate(merges)}
        self.special_tokens = list(special_tokens)
        self.special_ids = {tok: i for i, tok in enumerate(special_tokens)}
        self._inv = {v: k for k, v in vocab.items()}
        for tok in special_tokens:
            self.special_ids[tok] = self._inv[tok.encode("utf-8")]
        # pair -> id of the token it merges into.  Derived from the vocabulary
        # rather than assumed from the merge order, so a hand-edited or externally
        # trained vocabulary still encodes correctly.
        self.pair_to_id = {
            (a, b): self._inv[vocab[a] + vocab[b]]
            for (a, b) in merges if vocab[a] + vocab[b] in self._inv
        }
        self._cache: dict[str, tuple[int, ...]] = {}
        self._split_re = (re.compile("(" + "|".join(re.escape(t) for t in special_tokens) + ")")
                          if special_tokens else None)

    # -- properties -----------------------------------------------------------
    @property
    def vocab_size(self) -> int:
        return len(self.vocab)

    # -- core -----------------------------------------------------------------
    def _encode_word(self, word: str) -> tuple[int, ...]:
        cached = self._cache.get(word)
        if cached is not None:
            return cached
        ids = list(word.encode("utf-8"))
        while len(ids) >= 2:
            # Apply the *earliest-learned* applicable merge, not the leftmost one.
            best, best_rank = None, len(self.ranks) + 1
            for i in range(len(ids) - 1):
                r = self.ranks.get((ids[i], ids[i + 1]))
                if r is not None and r < best_rank:
                    best, best_rank = i, r
            if best is None:
                break
            ids[best:best + 2] = [self.pair_to_id[(ids[best], ids[best + 1])]]
        out = tuple(ids)
        if len(self._cache) < 500_000:
            self._cache[word] = out
        return out

    def encode(self, text: str) -> list[int]:
        out: list[int] = []
        parts = self._split_re.split(text) if self._split_re else [text]
        for part in parts:
            if not part:
                continue
            if part in self.special_ids:
                out.append(self.special_ids[part])
                continue
            for word in pretokenize(part):
                out.extend(self._encode_word(word))
        return out

    def decode(self, ids: Iterable[int]) -> str:
        raw = b"".join(self.vocab.get(i, b"") for i in ids)
        return raw.decode("utf-8", errors="replace")

    # -- persistence ----------------------------------------------------------
    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({
                "vocab": {str(k): list(v) for k, v in self.vocab.items()},
                "merges": [list(p) for p in self.merges],
                "special_tokens": self.special_tokens,
            }, f)

    @classmethod
    def load(cls, path: str) -> "Tokenizer":
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        vocab = {int(k): bytes(v) for k, v in d["vocab"].items()}
        merges = [tuple(p) for p in d["merges"]]
        return cls(vocab, merges, d["special_tokens"])


# -- corpus encoding, one core and many ---------------------------------------

_WORKER_TOK: Tokenizer | None = None


def _worker_init(tok: Tokenizer) -> None:
    global _WORKER_TOK
    _WORKER_TOK = tok


def _worker_encode(chunk: str) -> np.ndarray:
    assert _WORKER_TOK is not None
    return np.asarray(_WORKER_TOK.encode(chunk), dtype=np.uint16)


def split_on_boundaries(text: str, n_chunks: int, sep: str = END_OF_TEXT) -> list[str]:
    """Cut text into roughly equal chunks, always at a document boundary.

    Splitting mid-document would create merges across a seam that the single-core
    encoder would never produce, so the parallel result would not be bit-identical
    to the serial one — and "the fast version gives a different answer" is not a
    result you want to explain to a user.
    """
    if n_chunks <= 1:
        return [text]
    docs = text.split(sep)
    per = max(1, len(docs) // n_chunks)
    chunks, buf = [], []
    for d in docs:
        buf.append(d)
        if len(buf) >= per and len(chunks) < n_chunks - 1:
            chunks.append(sep.join(buf) + sep)
            buf = []
    if buf:
        chunks.append(sep.join(buf))
    return [c for c in chunks if c]


def encode_corpus(tok: Tokenizer, text: str, n_workers: int = 1) -> tuple[np.ndarray, float]:
    """Tokenise a whole corpus, optionally across many CPU cores.

    Args:
        tok: a trained tokeniser.
        text: the corpus.
        n_workers: processes to use.  1 means plain serial encoding.

    Returns:
        (uint16 token array, wall-clock seconds).
    """
    t0 = time.perf_counter()
    if n_workers <= 1:
        ids = np.asarray(tok.encode(text), dtype=np.uint16)
        return ids, time.perf_counter() - t0

    import multiprocessing as mp

    chunks = split_on_boundaries(text, n_workers * 2)
    use_fork = os.name == "posix" and "fork" in mp.get_all_start_methods()
    if use_fork:
        # Publish the tokeniser as a module global BEFORE forking, so the children
        # inherit it through copy-on-write. Passing it as an initializer argument
        # instead would pickle the whole 10,000-token vocabulary once per worker,
        # which on a short job costs more than the work itself -- the classic way to
        # make a parallel version slower than the serial one.
        global _WORKER_TOK
        _WORKER_TOK = tok
        ctx = mp.get_context("fork")
        pool_kwargs = {}
    else:
        ctx = mp
        pool_kwargs = {"initializer": _worker_init, "initargs": (tok,)}

    with ctx.Pool(n_workers, **pool_kwargs) as pool:
        parts = pool.map(_worker_encode, chunks)
    ids = np.concatenate(parts) if parts else np.zeros(0, dtype=np.uint16)
    return ids, time.perf_counter() - t0


# ═══════════════════════════════════════════════════════════════════════════════
# 4. MODEL — a Llama-style decoder
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class GPTConfig:
    """Shape of the model.  Everything downstream — parameter count, FLOPs per
    token, memory, throughput — is a function of these seven numbers."""

    vocab_size: int = 10_000
    context_len: int = 256
    d_model: int = 384
    n_layers: int = 6
    n_heads: int = 6
    d_ff: int = 1024          # SwiGLU hidden width; Llama uses ~8/3 * d_model
    rope_theta: float = 10_000.0

    @property
    def head_dim(self) -> int:
        assert self.d_model % self.n_heads == 0, "d_model must divide evenly into heads"
        return self.d_model // self.n_heads


class RMSNorm(nn.Module):
    """Root-mean-square normalisation (Llama, T5).

    LayerNorm subtracts the mean and divides by the standard deviation; RMSNorm
    skips the mean.  It costs one pass over the row instead of two and, empirically,
    trains just as well — the first of many places where a from-scratch model gives
    up a little generality to go faster.
    """

    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        x = x.float()
        x = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return (x * self.weight.float()).to(dtype)


def rope_tables(context_len: int, head_dim: int, theta: float, device, dtype=torch.float32):
    """Pre-compute the cosine/sine tables for rotary position embeddings.

    RoPE encodes position by *rotating* each pair of channels in a query or key by an
    angle proportional to its position.  The dot product of two rotated vectors then
    depends only on the difference of their positions, so the model learns relative
    position for free and generalises past the training length better than a learned
    position table would.

    Returns:
        (cos, sin), each shaped (context_len, head_dim // 2).
    """
    inv_freq = 1.0 / (theta ** (torch.arange(0, head_dim, 2, device=device).float() / head_dim))
    pos = torch.arange(context_len, device=device).float()
    ang = torch.outer(pos, inv_freq)
    return ang.cos().to(dtype), ang.sin().to(dtype)


def apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    """Rotate every (even, odd) channel pair of `x` by its position's angle.

    Args:
        x: (batch, heads, seq, head_dim)
        cos, sin: (seq, head_dim // 2) from `rope_tables`.

    Returns:
        Tensor of the same shape as `x`.
    """
    x1, x2 = x[..., 0::2], x[..., 1::2]
    c, s = cos[None, None, : x.shape[-2], :], sin[None, None, : x.shape[-2], :]
    out = torch.empty_like(x)
    out[..., 0::2] = x1 * c - x2 * s
    out[..., 1::2] = x1 * s + x2 * c
    return out


class SwiGLU(nn.Module):
    """The feed-forward block: SiLU-gated, as in Llama and PaLM.

    Two thirds of every transformer's parameters and FLOPs live here, not in
    attention.  That is worth remembering when you are asked why a model is slow.
    """

    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.w_gate = nn.Linear(d_model, d_ff, bias=False)
        self.w_up = nn.Linear(d_model, d_ff, bias=False)
        self.w_down = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.w_down(F.silu(self.w_gate(x)) * self.w_up(x))


class FlashCausalSelfAttention(nn.Module):
    """The same maths as the attention you write in Exercise 2, handed to PyTorch.

    `scaled_dot_product_attention` dispatches to a fused kernel (FlashAttention on
    Hopper) that never writes the seq x seq score matrix to memory: it walks the
    sequence in tiles that stay in on-chip SRAM.  Identical outputs, a fraction of
    the memory traffic.  Part 3 measures the difference.
    """

    def __init__(self, cfg: GPTConfig):
        super().__init__()
        self.cfg = cfg
        self.qkv = nn.Linear(cfg.d_model, 3 * cfg.d_model, bias=False)
        self.proj = nn.Linear(cfg.d_model, cfg.d_model, bias=False)

    def forward(self, x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        H, D = self.cfg.n_heads, self.cfg.head_dim
        q, k, v = self.qkv(x).split(C, dim=2)
        q = q.view(B, T, H, D).transpose(1, 2)
        k = k.view(B, T, H, D).transpose(1, 2)
        v = v.view(B, T, H, D).transpose(1, 2)
        q, k = apply_rope(q, cos, sin), apply_rope(k, cos, sin)
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.proj(y.transpose(1, 2).contiguous().view(B, T, C))


class Block(nn.Module):
    """One transformer layer: pre-norm attention, then pre-norm feed-forward.

    The two residual additions are what let gradients reach layer 1 from layer 6.
    Pre-norm (normalise *before* the sublayer) is what lets you train it without a
    warm-up babysitter.
    """

    def __init__(self, cfg: GPTConfig, attn_cls):
        super().__init__()
        self.norm1 = RMSNorm(cfg.d_model)
        self.attn = attn_cls(cfg)
        self.norm2 = RMSNorm(cfg.d_model)
        self.ffn = SwiGLU(cfg.d_model, cfg.d_ff)

    def forward(self, x, cos, sin):
        x = x + self.attn(self.norm1(x), cos, sin)
        return x + self.ffn(self.norm2(x))


class GPT(nn.Module):
    """The whole model: embed, N blocks, norm, project back to the vocabulary.

    Args:
        cfg: model shape.
        attn_cls: the attention module to use.  The notebook passes in the class the
            participant wrote, so Exercise 2's code really is the one that trains.
    """

    def __init__(self, cfg: GPTConfig, attn_cls=FlashCausalSelfAttention):
        super().__init__()
        self.cfg = cfg
        self.embed = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.blocks = nn.ModuleList([Block(cfg, attn_cls) for _ in range(cfg.n_layers)])
        self.norm_f = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        cos, sin = rope_tables(cfg.context_len, cfg.head_dim, cfg.rope_theta, "cpu")
        self.register_buffer("rope_cos", cos, persistent=False)
        self.register_buffer("rope_sin", sin, persistent=False)
        self.apply(self._init)

    @staticmethod
    def _init(m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)

    def forward(self, idx: torch.Tensor, targets: torch.Tensor | None = None):
        """Args:
            idx: (batch, seq) token ids.
            targets: (batch, seq) next-token ids, or None for inference.

        Returns:
            (logits, loss) — loss is None when targets is None.
        """
        T = idx.shape[1]
        x = self.embed(idx)
        cos, sin = self.rope_cos[:T], self.rope_sin[:T]
        for block in self.blocks:
            x = block(x, cos, sin)
        logits = self.lm_head(self.norm_f(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss

    # -- accounting -----------------------------------------------------------
    def n_params(self, non_embedding: bool = False) -> int:
        n = sum(p.numel() for p in self.parameters())
        if non_embedding:
            n -= self.embed.weight.numel() + self.lm_head.weight.numel()
        return n

    @torch.no_grad()
    def generate(self, tok: Tokenizer, prompt: str, max_new_tokens: int = 120,
                 temperature: float = 0.8, top_k: int = 50, device: str = "cpu") -> str:
        """Sample a continuation, one token at a time.

        Temperature flattens or sharpens the distribution; top-k throws away the long
        tail that produces non-words.  Both are inference knobs and change nothing
        about the trained model.
        """
        self.eval()
        ids = tok.encode(prompt) or [tok.special_ids[END_OF_TEXT]]
        x = torch.tensor([ids], dtype=torch.long, device=device)
        for _ in range(max_new_tokens):
            logits, _ = self(x[:, -self.cfg.context_len:])
            logits = logits[:, -1, :].float() / max(temperature, 1e-5)
            if top_k:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float("inf")
            nxt = torch.multinomial(F.softmax(logits, dim=-1), num_samples=1)
            x = torch.cat([x, nxt], dim=1)
            if nxt.item() == tok.special_ids.get(END_OF_TEXT, -1):
                break
        self.train()
        return tok.decode(x[0].tolist())


# ═══════════════════════════════════════════════════════════════════════════════
# 5. TRAINING
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class TrainConfig:
    batch_size: int = 32
    context_len: int = 256
    lr: float = 3e-3
    min_lr_frac: float = 0.1
    warmup_steps: int = 100
    grad_clip: float = 1.0
    weight_decay: float = 0.1
    betas: tuple[float, float] = (0.9, 0.95)
    eval_every: int = 100
    eval_batches: int = 20
    log_every: int = 25


@dataclass
class History:
    """Everything a training run produced, in one object we can plot and report."""

    step: list[int] = field(default_factory=list)
    train_loss: list[float] = field(default_factory=list)
    wall: list[float] = field(default_factory=list)        # seconds since start
    tokens: list[int] = field(default_factory=list)        # tokens consumed so far
    eval_step: list[int] = field(default_factory=list)
    eval_loss: list[float] = field(default_factory=list)
    samples: list[tuple[int, str]] = field(default_factory=list)
    tokens_per_sec: float = 0.0
    total_seconds: float = 0.0


def lr_at(step: int, cfg: TrainConfig, total_steps: int) -> float:
    """Linear warm-up, then cosine decay to `min_lr_frac * lr`.

    The warm-up exists because AdamW's second-moment estimate is garbage for the
    first few dozen steps; stepping at full learning rate on a garbage denominator
    is the classic way to blow up a fresh transformer in the first minute.
    """
    if step < cfg.warmup_steps:
        return cfg.lr * (step + 1) / cfg.warmup_steps
    if step >= total_steps:
        return cfg.lr * cfg.min_lr_frac
    prog = (step - cfg.warmup_steps) / max(1, total_steps - cfg.warmup_steps)
    cos = 0.5 * (1 + math.cos(math.pi * prog))
    return cfg.lr * (cfg.min_lr_frac + (1 - cfg.min_lr_frac) * cos)


def get_batch(tokens: np.ndarray, batch_size: int, context_len: int, device: str,
              rng: np.random.Generator) -> tuple[torch.Tensor, torch.Tensor]:
    """Sample a batch of (input, next-token) pairs from a flat token stream.

    There is no shuffling of documents and no padding: the corpus is one long array
    of ids, and a training example is any window of `context_len + 1` tokens in it.
    Sequences therefore run across story boundaries, which is fine — the model learns
    that `<|endoftext|>` means "start again".

    Returns:
        (x, y), each (batch_size, context_len) int64 on `device`.
    """
    ix = rng.integers(0, len(tokens) - context_len - 1, size=batch_size)
    x = np.stack([tokens[i: i + context_len] for i in ix]).astype(np.int64)
    y = np.stack([tokens[i + 1: i + 1 + context_len] for i in ix]).astype(np.int64)
    xt, yt = torch.from_numpy(x), torch.from_numpy(y)
    if device == "cuda":
        # pin_memory + non_blocking lets the copy overlap with compute on the
        # previous batch.  On a GH200 the CPU and GPU share memory over NVLink-C2C
        # at 900 GB/s, so this transfer is nearly free — on a PCIe machine it is not.
        xt, yt = xt.pin_memory(), yt.pin_memory()
        return xt.to(device, non_blocking=True), yt.to(device, non_blocking=True)
    return xt.to(device), yt.to(device)


def make_optimizer(model: nn.Module, cfg: TrainConfig, fused: bool = True):
    """AdamW, with weight decay on matrices only.

    Decaying gains and biases (the 1-D parameters) shrinks normalisation scales
    toward zero for no benefit; every serious implementation splits the groups.
    `fused=True` runs the whole update as one CUDA kernel instead of a few hundred.
    """
    decay = [p for p in model.parameters() if p.dim() >= 2 and p.requires_grad]
    no_decay = [p for p in model.parameters() if p.dim() < 2 and p.requires_grad]
    groups = [{"params": decay, "weight_decay": cfg.weight_decay},
              {"params": no_decay, "weight_decay": 0.0}]
    can_fuse = fused and next(model.parameters()).is_cuda
    return torch.optim.AdamW(groups, lr=cfg.lr, betas=cfg.betas, fused=can_fuse)


@torch.no_grad()
def evaluate(model: nn.Module, tokens: np.ndarray, cfg: TrainConfig, device: str,
             amp_dtype=None, n_batches: int = 20) -> float:
    """Mean cross-entropy on held-out tokens, in nats per token."""
    model.eval()
    rng = np.random.default_rng(SEED)
    losses = []
    for _ in range(n_batches):
        xb, yb = get_batch(tokens, cfg.batch_size, cfg.context_len, device, rng)
        with autocast_ctx(device, amp_dtype):
            _, loss = model(xb, yb)
        losses.append(loss.item())
    model.train()
    return float(np.mean(losses))


def autocast_ctx(device: str, amp_dtype):
    """Autocast if we were asked for it, otherwise a no-op context."""
    import contextlib

    if amp_dtype is None or device != "cuda":
        return contextlib.nullcontext()
    return torch.autocast(device_type="cuda", dtype=amp_dtype)


def try_compile(model: GPT, device: str) -> nn.Module:
    """`torch.compile(model)` if this environment can compile, else `model` unchanged.

    torch.compile is lazy: nothing compiles until the first call, so a broken
    toolchain (Triton builds a C helper and needs gcc and Python.h) would only
    surface mid-training.  One forward pass here finds out before the clock starts.
    """
    if device != "cuda":
        return model
    compiled = torch.compile(model)
    try:
        with torch.no_grad():
            compiled(torch.zeros(1, model.cfg.context_len, dtype=torch.long, device=device))
        return compiled
    except Exception as exc:
        print(f"  torch.compile unavailable here ({type(exc).__name__}) — running uncompiled.")
        torch._dynamo.reset()
        return model


def run_training(model: nn.Module, optimizer, step_fn: Callable, train_tokens: np.ndarray,
                 valid_tokens: np.ndarray, cfg: TrainConfig, device: str,
                 minutes: float = 6.0, max_steps: int | None = None,
                 amp_dtype=None, tokenizer: "Tokenizer | None" = None,
                 sample_prompt: str = "Once upon a time", sample_at: Sequence[float] = (0.0, 0.25, 1.0),
                 verbose: bool = True) -> History:
    """Train until the time budget or the step budget runs out, whichever comes first.

    Args:
        model, optimizer: the things being trained.
        step_fn: the participant's `train_step`.  Every measurement in this notebook
            goes through it, so their code is genuinely what we are timing.
        train_tokens, valid_tokens: flat uint16 arrays of ids.
        cfg: batch size, learning rate, schedule.
        device: "cuda" or "cpu".
        minutes: wall-clock budget.  A supercomputing centre schedules time, not
            epochs, so this is the honest way to state a run.
        max_steps: optional hard cap; the LR schedule is built from it when given.
        amp_dtype: torch.bfloat16 to train in mixed precision, None for fp32.
        tokenizer: if given, generate a sample at each fraction in `sample_at`.

    Returns:
        A `History` with losses, timings and the text samples.
    """
    hist = History()
    rng = np.random.default_rng(SEED)
    budget = minutes * 60.0
    total_steps = max_steps if max_steps is not None else 10_000
    sample_marks = sorted(set(sample_at))
    next_mark = 0

    model.train()
    sync(device)
    t0 = time.perf_counter()
    step = 0
    tokens_seen = 0
    while True:
        elapsed = time.perf_counter() - t0
        frac = max(elapsed / budget, step / total_steps if max_steps else 0.0)
        if elapsed >= budget or (max_steps and step >= max_steps):
            break

        if tokenizer is not None and next_mark < len(sample_marks) and frac >= sample_marks[next_mark]:
            t_gen = time.perf_counter()
            hist.samples.append((step, model.generate(tokenizer, sample_prompt, 100, device=device)))
            next_mark += 1
            # Sampling is diagnostics, not training.  Push the clock forward so it is
            # not charged to the throughput figure we are about to quote.
            t0 += time.perf_counter() - t_gen

        lr = lr_at(step, cfg, total_steps if max_steps else int(total_steps))
        for g in optimizer.param_groups:
            g["lr"] = lr

        xb, yb = get_batch(train_tokens, cfg.batch_size, cfg.context_len, device, rng)
        loss = step_fn(model, optimizer, xb, yb, amp_dtype, cfg.grad_clip)

        step += 1
        tokens_seen += cfg.batch_size * cfg.context_len
        if step % cfg.log_every == 0:
            hist.step.append(step)
            hist.train_loss.append(float(loss))
            hist.wall.append(time.perf_counter() - t0)
            hist.tokens.append(tokens_seen)
            if verbose and step % (cfg.log_every * 4) == 0:
                tps = tokens_seen / (time.perf_counter() - t0)
                print(f"  step {step:5d} | loss {float(loss):5.3f} | lr {lr:.2e} | "
                      f"{tps/1e3:7.1f}k tok/s | {time.perf_counter()-t0:5.0f}s")
        if step % cfg.eval_every == 0:
            vl = evaluate(model, valid_tokens, cfg, device, amp_dtype, cfg.eval_batches)
            hist.eval_step.append(step)
            hist.eval_loss.append(vl)

    sync(device)
    hist.total_seconds = time.perf_counter() - t0
    hist.tokens_per_sec = tokens_seen / hist.total_seconds
    if not hist.eval_step:
        hist.eval_step.append(step)
        hist.eval_loss.append(evaluate(model, valid_tokens, cfg, device, amp_dtype, 5))
    if tokenizer is not None:
        hist.samples.append((step, model.generate(tokenizer, sample_prompt, 120, device=device)))
    if verbose:
        print(f"\n  done: {step} steps, {tokens_seen/1e6:.1f}M tokens in "
              f"{hist.total_seconds:.0f}s = {hist.tokens_per_sec/1e3:.1f}k tokens/s")
    return hist


def measure_throughput(model: nn.Module, optimizer, step_fn: Callable, tokens: np.ndarray,
                       cfg: TrainConfig, device: str, amp_dtype=None,
                       n_steps: int = 20, warmup: int = 5) -> dict:
    """Time `n_steps` training steps and report tokens/s and peak memory.

    The warm-up steps are thrown away: the first call allocates workspaces, picks
    kernels, and (with torch.compile) compiles the graph.  Including them in the
    average is the second most common benchmarking mistake, after forgetting to
    synchronise.

    Returns:
        dict with tokens_per_sec, sec_per_step, peak_mem_gb, ok (False if the
        configuration ran out of memory).
    """
    rng = np.random.default_rng(SEED)
    batches = [get_batch(tokens, cfg.batch_size, cfg.context_len, device, rng)
               for _ in range(warmup + n_steps)]
    try:
        if device == "cuda":
            torch.cuda.reset_peak_memory_stats()
        for i in range(warmup):
            step_fn(model, optimizer, *batches[i], amp_dtype, cfg.grad_clip)
        sync(device)
        t0 = time.perf_counter()
        for i in range(warmup, warmup + n_steps):
            step_fn(model, optimizer, *batches[i], amp_dtype, cfg.grad_clip)
        sync(device)
        dt = time.perf_counter() - t0
    except torch.cuda.OutOfMemoryError:
        torch.cuda.empty_cache()
        return {"ok": False, "tokens_per_sec": 0.0, "sec_per_step": float("nan"),
                "peak_mem_gb": float("nan")}
    toks = n_steps * cfg.batch_size * cfg.context_len
    return {
        "ok": True,
        "tokens_per_sec": toks / dt,
        "sec_per_step": dt / n_steps,
        "peak_mem_gb": torch.cuda.max_memory_allocated() / 1e9 if device == "cuda" else float("nan"),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 6. PLOTS
# ═══════════════════════════════════════════════════════════════════════════════

def plot_speedup_ladder(results: dict[str, float],
                        title: str = "One GPU, five decisions"):
    """Horizontal bars of tokens/s per configuration, annotated with MFU.

    Colour carries one meaning here: GRAY is the starting point, PURPLE an intermediate
    configuration, GREEN the fastest one found.
    """
    import matplotlib.pyplot as plt

    names = list(results.keys())
    vals = [results[n] for n in names]
    best = max(vals)
    colors = [GRAY if i == 0 else (GREEN if v == best else PURPLE) for i, v in enumerate(vals)]

    fig, ax = plt.subplots(figsize=(8.2, 0.52 * len(names) + 1.5))
    ax.barh(names, vals, color=colors, height=0.62)
    ax.invert_yaxis()
    for i, v in enumerate(vals):
        ax.text(v * 1.02, i, f"  {v:,.0f} tokens/s   ·   {v/vals[0]:,.0f}x", va="center", fontsize=8.5)
    if best / min(vals) > 30:          # CPU next to GPU: a linear axis hides the CPU bar
        ax.set_xscale("log")
        ax.set_xlim(min(vals) / 2, best * 40)
    else:
        ax.set_xlim(0, best * 1.75)
    ax.set_xlabel("training speed (tokens per second" + (", log scale)" if best / min(vals) > 30 else ")"))
    ax.set_title(title, loc="left", fontsize=11, weight="bold")
    ax.grid(axis="y", alpha=0)
    plt.tight_layout()
    plt.show()


def plot_training(hist: History, title: str = "Loss against wall-clock time"):
    """Loss against wall-clock, not against step.

    Plotting against step flatters whichever configuration takes the most time per
    step.  On a machine that is rented by the hour, the x-axis is seconds.
    """
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.4))
    axes[0].plot(hist.wall, hist.train_loss, color=GRAY, lw=1.2, label="train")
    if hist.eval_step:
        ev_wall = np.interp(hist.eval_step, hist.step or [0], hist.wall or [0])
        axes[0].plot(ev_wall, hist.eval_loss, "o-", color=PURPLE, lw=2, ms=4, label="validation")
    axes[0].set_xlabel("wall-clock seconds")
    axes[0].set_ylabel("cross-entropy loss (nats / token)")
    axes[0].set_title(title, loc="left", fontsize=10, weight="bold")
    axes[0].legend(frameon=False, fontsize=8)

    axes[1].plot([t / 1e6 for t in hist.tokens], hist.train_loss, color=PURPLE, lw=1.4)
    axes[1].set_xlabel("million tokens seen")
    axes[1].set_ylabel("cross-entropy loss")
    axes[1].set_title("The same run, charged in tokens", loc="left", fontsize=10, weight="bold")
    plt.tight_layout()
    plt.show()


# Diverging scale for values in [-1, 1]: teal below zero, purple above, a neutral grey
# at zero. A value scale, not one of the house colour meanings.
TEAL, NEUTRAL = "#2a8c82", "#eeeef2"


def plot_rope(cfg: GPTConfig | None = None, demo_dim: int = 8, demo_pos: int = 3):
    """Show RoPE as an HTML panel, in the style of the notebook's other panels.

    Left card: R_m for a toy head of `demo_dim` channels at position `demo_pos`, the
    matrix a query or key at that position is multiplied by. Right card: cos(m * w_i)
    for every position m and channel pair i of the real model. Both come from
    `rope_tables`, the same tables the model uses.
    """
    import base64
    import io
    import uuid
    import matplotlib.image as mpimg
    from matplotlib.colors import LinearSegmentedColormap, to_hex
    from IPython.display import HTML, display

    cfg = cfg or GPTConfig()
    cmap = LinearSegmentedColormap.from_list("rope", [TEAL, NEUTRAL, PURPLE2])
    ink, muted, faint = "#2d2b44", "#6b6880", "#9aa3b2"
    shade = lambda v: to_hex(cmap((v + 1) / 2))   # [-1, 1] -> colour

    # R_m, one 2x2 rotation per pair
    cos, sin = rope_tables(demo_pos + 1, demo_dim, cfg.rope_theta, "cpu", torch.float64)
    c, s = cos[demo_pos].numpy(), sin[demo_pos].numpy()
    R = np.zeros((demo_dim, demo_dim))
    for i in range(demo_dim // 2):
        R[2*i:2*i+2, 2*i:2*i+2] = [[c[i], -s[i]], [s[i], c[i]]]

    cell = 34
    cells = []
    for r in range(demo_dim):
        for col in range(demo_dim):
            v = R[r, col]
            in_block = r // 2 == col // 2
            edge = f"1.5px solid {ink}"
            border = ";".join(
                f"border-{side}:{edge if in_block and cond else '1px solid #f2f3f7'}"
                for side, cond in (("top", r % 2 == 0), ("bottom", r % 2 == 1),
                                   ("left", col % 2 == 0), ("right", col % 2 == 1)))
            lab = "" if v == 0 else (f"{v:.2f}" if abs(v) >= 0.1 else f"{v:.1g}").replace("-", "−")
            color = "#fff" if abs(v) > 0.6 else ink
            cells.append(f'<div style="width:{cell}px;height:{cell}px;box-sizing:border-box;'
                         f'background:{shade(v) if in_block else "#f7f7fa"};{border};'
                         f'display:flex;align-items:center;justify-content:center;'
                         f'font-size:10px;color:{color}">{lab}</div>')
    angles = "".join(
        f'<div style="width:{2*cell}px;text-align:center;font-size:10.5px;line-height:1.3;'
        f'color:{muted}">pair {i}<br><b style="color:{ink};font-weight:620">'
        f'{demo_pos * cfg.rope_theta ** (-2*i/demo_dim):.3g} rad</b></div>'
        for i in range(demo_dim // 2))
    matrix = (f'<div style="display:flex;margin-left:18px">{angles}</div>'
              f'<div style="display:flex;align-items:center;margin-top:4px">'
              f'<div style="writing-mode:vertical-rl;transform:rotate(180deg);font-size:10.5px;'
              f'color:{faint};width:18px;text-align:center">output channel</div>'
              f'<div style="display:grid;grid-template-columns:repeat({demo_dim},{cell}px)">'
              f'{"".join(cells)}</div></div>'
              f'<div style="margin-left:18px;width:{demo_dim*cell}px;text-align:center;'
              f'font-size:10.5px;color:{faint};margin-top:4px">input channel</div>')

    # cos(m w_i) for the real model, as a pixel image: one pixel per (position, pair)
    cos_full, _ = rope_tables(cfg.context_len, cfg.head_dim, cfg.rope_theta, "cpu")
    buf = io.BytesIO()
    mpimg.imsave(buf, cos_full.T.numpy(), cmap=cmap, vmin=-1, vmax=1, format="png")
    png = base64.b64encode(buf.getvalue()).decode()
    T, P = cfg.context_len, cfg.head_dim // 2
    xticks = "".join(f'<span>{t}</span>' for t in (0, T // 4, T // 2, 3 * T // 4, T - 1))
    table = (f'<div style="display:flex;gap:8px;align-items:stretch">'
             f'<div style="display:flex;flex-direction:column;justify-content:space-between;'
             f'font-size:10.5px;color:{muted};text-align:right;white-space:nowrap">'
             f'<span>pair 0<br><span style="color:{faint}">fast</span></span>'
             f'<span>pair {P - 1}<br><span style="color:{faint}">slow</span></span></div>'
             f'<img src="data:image/png;base64,{png}" alt="cos(m·ω_i) for every position and pair"'
             f' style="flex:1;min-width:0;height:{cell * demo_dim}px;image-rendering:pixelated;'
             f'border-radius:6px;border:1px solid #e6e8ee"></div>'
             f'<div style="display:flex;justify-content:space-between;font-size:10.5px;'
             f'color:{faint};margin:4px 0 0 52px">{xticks}</div>'
             f'<div style="text-align:center;font-size:10.5px;color:{faint}">position m</div>'
             f'<div style="display:flex;align-items:center;gap:8px;margin-top:10px;'
             f'font-size:10.5px;color:{muted}"><span>−1</span>'
             f'<div style="flex:1;height:8px;border-radius:4px;background:linear-gradient('
             f'90deg,{TEAL},{NEUTRAL},{PURPLE2})"></div><span>+1</span></div>')

    def spec(label, value, note):
        return (f'<div style="display:flex;justify-content:space-between;gap:10px;'
                f'padding:4px 0;border-bottom:1px solid #f2f3f7">'
                f'<span style="color:{muted};font-size:11.5px">{label}</span>'
                f'<span style="font-weight:620;font-size:11.5px;color:{ink}">{value}'
                f'<span style="font-weight:400;color:{faint}"> {note}</span></span></div>')

    w_slow = cfg.rope_theta ** (-2 * (P - 1) / cfg.head_dim)
    card = ("background:#fff;border:1px solid #e6e8ee;border-radius:14px;"
            "padding:12px 14px")
    uid = uuid.uuid4().hex[:8]
    display(HTML(f'''
    <div id="rp{uid}" style="font-family:system-ui,Segoe UI,Roboto,sans-serif;
         border-radius:18px;border:1px solid #ecebff;padding:18px 20px;
         background:linear-gradient(135deg,#f6f8ff,#fbf5ff)">
      <div style="font-size:13px;color:#764ba2;letter-spacing:.11em;font-weight:600">
        🌀 ROTARY POSITION EMBEDDINGS</div>
      <div style="font-size:19px;font-weight:700;color:{ink};margin:4px 0 4px">
        Position as a rotation, one 2×2 block per channel pair</div>
      <div style="font-size:12.5px;color:{muted};margin-bottom:14px;line-height:1.5">
        Both cards are computed from <code>util.rope_tables</code>, the tables the model
        itself uses.</div>

      <div style="display:flex;flex-wrap:wrap;gap:11px">
        <div style="{card};flex:0 1 auto">
          <div style="font-weight:700;color:#764ba2;font-size:13px;margin-bottom:9px">
            R<sub>m</sub> AT POSITION m = {demo_pos}
            <span style="font-weight:400;color:{faint}">toy head, D = {demo_dim}</span></div>
          {matrix}
          <div style="font-size:11px;color:{faint};margin-top:9px;line-height:1.45;
               max-width:{demo_dim*cell + 18}px">
            Zero outside the blocks, so no pair mixes with another. Pair 0 has turned
            almost half a circle; pair {demo_dim//2 - 1} is still nearly the identity.</div>
        </div>

        <div style="{card};flex:1 1 320px;min-width:280px">
          <div style="font-weight:700;color:#764ba2;font-size:13px;margin-bottom:9px">
            cos(m·ω<sub>i</sub>) FOR THE REAL MODEL
            <span style="font-weight:400;color:{faint}">D = {cfg.head_dim}, {T} positions</span></div>
          {table}
          <div style="font-size:11px;color:{faint};margin-top:9px;line-height:1.45">
            Fast pairs change from one token to the next and tell neighbours apart; slow
            pairs barely move in {T} tokens and measure long distances.</div>
        </div>
      </div>

      <div style="margin-top:11px">
        <div style="{card};border-color:#ecebff;background:#fcfbff">
          <div style="font-weight:700;color:#667eea;font-size:13px;margin-bottom:7px">
            IN NUMBERS</div>
          {spec("pairs per head", f"{P}", f"D / 2, D = {cfg.head_dim}")}
          {spec("fastest pair", "1 rad", "per token, ω₀")}
          {spec("slowest pair", f"{w_slow:.1e} rad", f"per token, one turn every {2*math.pi/w_slow:,.0f} tokens")}
          {spec("learned parameters", "0", "the angles are fixed by θ = " + f"{cfg.rope_theta:,.0f}")}
          {spec("applied to", "q and k", "never v")}
        </div>
      </div>

      <div style="margin-top:13px;font-size:11.5px;color:{muted};line-height:1.5">
        <code>util.apply_rope</code> applies the tables elementwise, so R<sub>m</sub> is
        never built as a matrix in the model; it is drawn here only to show what the
        rotation does.</div>
    </div>'''))


# ═══════════════════════════════════════════════════════════════════════════════
# 7. THE FAST BPE TRAINER  (builds the 10,000-token reference tokeniser)
# ═══════════════════════════════════════════════════════════════════════════════

def train_bpe_fast(text: str, vocab_size: int, special_tokens: Sequence[str] = (END_OF_TEXT,),
                   log_every: int = 0) -> tuple[dict[int, bytes], list[tuple[int, int]]]:
    """Same algorithm as `train_bpe`, same output, roughly a hundred times faster.

    The naive loop recounts every pair in the corpus after every merge.  But merging
    ("t","h") changes the pair counts only inside words that actually contained
    ("t","h") — a few hundred out of two hundred thousand.  So we keep an index from
    each pair to the words containing it, and on every merge we touch only those.

    This is the same move as a sparse matrix update, and it is the difference between
    a tokeniser that trains in twenty seconds and one that trains in half an hour.
    Worth doing before you ask for a bigger machine: no GPU fixes an O(n^2) loop.

    Returns:
        (vocab, merges), identical to `train_bpe`.
    """
    vocab: dict[int, bytes] = {i: bytes([i]) for i in range(256)}
    for i, tok in enumerate(special_tokens):
        vocab[256 + i] = tok.encode("utf-8")
    next_id = 256 + len(special_tokens)

    wf = word_frequencies(text)
    words = [list(w) for w in wf]
    freqs = list(wf.values())

    pair_counts: Counter = Counter()
    where: dict[tuple[int, int], set[int]] = {}
    for i, w in enumerate(words):
        f = freqs[i]
        for p in zip(w, w[1:]):
            pair_counts[p] += f
            where.setdefault(p, set()).add(i)

    merges: list[tuple[int, int]] = []
    t0 = time.perf_counter()
    while next_id < vocab_size and pair_counts:
        best = max(pair_counts.items(),
                   key=lambda kv: (kv[1], vocab[kv[0][0]], vocab[kv[0][1]]))[0]
        if pair_counts[best] <= 0:
            break
        a, b = best
        new_id = next_id
        vocab[new_id] = vocab[a] + vocab[b]

        for i in list(where.get(best, ())):
            w = words[i]
            f = freqs[i]
            if len(w) < 2:
                continue
            for p in zip(w, w[1:]):                     # retire the old pairs
                pair_counts[p] -= f
                if pair_counts[p] <= 0:
                    pair_counts.pop(p, None)
                    where.pop(p, None)
            out, j = [], 0
            while j < len(w):
                if j < len(w) - 1 and w[j] == a and w[j + 1] == b:
                    out.append(new_id)
                    j += 2
                else:
                    out.append(w[j])
                    j += 1
            words[i] = out
            for p in zip(out, out[1:]):                 # and register the new ones
                pair_counts[p] += f
                where.setdefault(p, set()).add(i)

        pair_counts.pop(best, None)
        where.pop(best, None)
        merges.append(best)
        next_id += 1
        if log_every and len(merges) % log_every == 0:
            print(f"    {len(merges):5d} merges  {time.perf_counter()-t0:6.1f}s  "
                  f"newest: {vocab[new_id]!r}")
    return vocab, merges


# ═══════════════════════════════════════════════════════════════════════════════
# 8. INFERENCE — generating text, and what it costs
# ═══════════════════════════════════════════════════════════════════════════════

def unwrap(model: nn.Module) -> nn.Module:
    """The plain module underneath torch.compile (and DDP), whichever is on top."""
    model = getattr(model, "module", model)
    return getattr(model, "_orig_mod", model)


def inference_copy(model: nn.Module, device: str) -> GPT:
    """A copy of a trained model set up the way it would be served.

    Evaluation mode, on `device`, and on a GPU in bf16 throughout -- weights
    included, not just autocast -- because at inference every step reads every
    weight, and half the bytes is half the time once the model is big enough to be
    memory-bound.
    """
    import copy

    m = copy.deepcopy(unwrap(model)).to(device).eval()
    if device == "cuda" and torch.cuda.is_bf16_supported():
        m = m.to(torch.bfloat16)
    return m


class KVCache:
    """Keys and values of every position generated so far, for every layer.

    A decoder generates one token per step.  Without a cache, step t recomputes
    the keys and values of all t earlier positions, which were already computed at
    step t-1 and have not changed -- position 5 cannot see position 6, so nothing
    about it ever changes.  The cache stores them once, preallocated to the final
    length, so each step only computes the ONE new position.

    Shape of each buffer: (n_layers, batch, n_heads, max_len, head_dim).
    """

    def __init__(self, cfg: GPTConfig, batch: int, max_len: int, device, dtype):
        shape = (cfg.n_layers, batch, cfg.n_heads, max_len, cfg.head_dim)
        self.k = torch.zeros(shape, device=device, dtype=dtype)
        self.v = torch.zeros_like(self.k)

    @property
    def nbytes(self) -> int:
        return 2 * self.k.numel() * self.k.element_size()


def decode_attention_reference(q, k_new, v_new, cache_k, cache_v, pos):
    """util.py's own decode step, the reference for Exercise 6.

    q, k_new, v_new: (B, H, 1, D) for the one new position, RoPE already applied.
    cache_k, cache_v: (B, H, max_len, D), positions [0, pos) already filled.
    """
    cache_k[:, :, pos:pos + 1] = k_new
    cache_v[:, :, pos:pos + 1] = v_new
    return F.scaled_dot_product_attention(q, cache_k[:, :, :pos + 1], cache_v[:, :, :pos + 1])


@torch.no_grad()
def forward_cached(model: nn.Module, idx: torch.Tensor, cache: KVCache, pos: int,
                   decode_attn: Callable = decode_attention_reference) -> torch.Tensor:
    """Run the model on `idx` (positions pos .. pos+T-1), filling the cache.

    Two regimes, and they are the two phases of every LLM server:
      * prefill (T > 1, pos == 0): the whole prompt at once, causal attention, and
        its keys and values written into the cache.  Compute-bound, like training.
      * decode  (T == 1): one new token attends over everything in the cache,
        through `decode_attn` -- the participant's function in Exercise 6.

    The model's own weights are used (qkv, proj, the norms, the feed-forward), so
    whichever attention class it was built with, the arithmetic is the same.

    Returns:
        logits for the LAST position only, shape (B, vocab).
    """
    m = unwrap(model)
    cfg = m.cfg
    B, T = idx.shape
    H, D, C = cfg.n_heads, cfg.head_dim, cfg.d_model
    assert T == 1 or pos == 0, "prefill must start at position 0"
    x = m.embed(idx)
    cos, sin = m.rope_cos[pos:pos + T], m.rope_sin[pos:pos + T]
    for layer, blk in enumerate(m.blocks):
        q, k, v = blk.attn.qkv(blk.norm1(x)).split(C, dim=2)
        q = q.view(B, T, H, D).transpose(1, 2)
        k = k.view(B, T, H, D).transpose(1, 2)
        v = v.view(B, T, H, D).transpose(1, 2)
        q, k = apply_rope(q, cos, sin), apply_rope(k, cos, sin)
        if T > 1:
            cache.k[layer, :, :, :T] = k
            cache.v[layer, :, :, :T] = v
            y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        else:
            y = decode_attn(q, k, v, cache.k[layer], cache.v[layer], pos)
        x = x + blk.attn.proj(y.transpose(1, 2).contiguous().view(B, T, C))
        x = x + blk.ffn(blk.norm2(x))
    return m.lm_head(m.norm_f(x[:, -1:]))[:, 0]


def _pick(logits: torch.Tensor, temperature: float, top_k: int, gen) -> torch.Tensor:
    if temperature <= 0:
        return logits.argmax(-1, keepdim=True)
    logits = logits.float() / temperature
    if top_k:
        v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
        logits[logits < v[:, [-1]]] = -float("inf")
    return torch.multinomial(F.softmax(logits, dim=-1), 1, generator=gen)


@torch.no_grad()
def generate_ids(model: nn.Module, prompt: torch.Tensor, n_new: int, use_cache: bool = True,
                 decode_attn: Callable = decode_attention_reference,
                 temperature: float = 0.0, top_k: int = 50, seed: int = SEED) -> torch.Tensor:
    """Generate `n_new` tokens for a whole batch of prompts at once.

    Args:
        prompt: (B, T0) token ids.  T0 + n_new must fit in the context length.
        use_cache: False recomputes every earlier position at every step -- the
            naive loop -- which is what `GPT.generate` does.
        temperature: 0 means greedy (deterministic, used for timing and checks).

    Returns:
        (B, T0 + n_new) token ids.
    """
    m = unwrap(model)
    B, T0 = prompt.shape
    assert T0 + n_new <= m.cfg.context_len, "prompt + new tokens exceed the context length"
    gen = torch.Generator(device=prompt.device).manual_seed(seed) if temperature > 0 else None
    seq = prompt
    if use_cache:
        cache = KVCache(m.cfg, B, T0 + n_new, prompt.device, next(m.parameters()).dtype)
        logits = forward_cached(m, prompt, cache, 0, decode_attn)
    else:
        logits = m(seq)[0][:, -1]
    for i in range(n_new):
        nxt = _pick(logits, temperature, top_k, gen)
        seq = torch.cat([seq, nxt], dim=1)
        if i == n_new - 1:
            break
        logits = (forward_cached(m, nxt, cache, T0 + i, decode_attn) if use_cache
                  else m(seq)[0][:, -1])
    return seq


def measure_generation(model: nn.Module, device: str, batch: int, n_new: int = 128,
                       prompt_len: int = 16, use_cache: bool = True,
                       decode_attn: Callable = decode_attention_reference) -> dict:
    """Time the generation of `n_new` tokens for `batch` sequences at once.

    Returns:
        dict with ok, tokens_per_sec (new tokens across the whole batch),
        ms_per_step (latency: one step emits one token per sequence),
        weight_gb_per_sec (every step reads every weight once).
    """
    m = unwrap(model)
    g = torch.Generator().manual_seed(SEED)
    prompt = torch.randint(0, m.cfg.vocab_size, (batch, prompt_len), generator=g).to(device)
    try:
        generate_ids(m, prompt, 4, use_cache, decode_attn)          # warm-up
        sync(device)
        t0 = time.perf_counter()
        generate_ids(m, prompt, n_new, use_cache, decode_attn)
        sync(device)
        dt = time.perf_counter() - t0
    except torch.cuda.OutOfMemoryError:
        torch.cuda.empty_cache()
        return {"ok": False, "batch": batch, "tokens_per_sec": 0.0,
                "ms_per_step": float("nan"), "weight_gb_per_sec": float("nan")}
    weight_bytes = sum(p.numel() * p.element_size() for p in m.parameters())
    return {"ok": True, "batch": batch, "tokens_per_sec": batch * n_new / dt,
            "ms_per_step": dt / n_new * 1e3,
            "weight_gb_per_sec": weight_bytes * n_new / dt / 1e9}


def plot_generation(rows: dict[str, list[dict]], title: str = "Writing many stories at once"):
    """Two panels over the same axis, the number of sequences generated together:
    tokens per second (it grows with the batch) and the time of one step (it barely
    moves) -- the second is the reason for the first.  rows: label -> results."""
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FixedLocator, FuncFormatter, LogLocator, NullLocator

    fig, (ax_t, ax_s) = plt.subplots(1, 2, figsize=(10.2, 3.7))
    batches = sorted({r["batch"] for rs in rows.values() for r in rs if r["ok"]})
    for label, rs in rows.items():
        ok = [r for r in rs if r["ok"]]
        if not ok:
            continue
        colour = GRAY if label.lower().startswith("cpu") else PURPLE
        short = label.split(" · ")[0]                       # "CPU" or "GPU"
        xs = [r["batch"] for r in ok]
        ax_t.plot(xs, [r["tokens_per_sec"] for r in ok], "o-", color=colour, lw=2, ms=6, label=short)
        ax_s.plot(xs, [r["ms_per_step"] for r in ok], "o-", color=colour, lw=2, ms=6, label=short)
        last = ok[-1]
        ax_t.annotate(f"{short}: {last['tokens_per_sec']:,.0f} tokens/s", (last["batch"], last["tokens_per_sec"]),
                      xytext=(7, 0), textcoords="offset points", va="center", fontsize=8.5)
        ax_s.annotate(f"{short}: {last['ms_per_step']:.1f} ms", (last["batch"], last["ms_per_step"]),
                      xytext=(7, 0), textcoords="offset points", va="center", fontsize=8.5)
    for ax in (ax_t, ax_s):
        # Scale first, then limits: a limit set on a linear axis reaches down to zero,
        # which a log axis turns into dozens of empty decades.
        ax.set_xscale("log", base=2)
        ax.set_xlim(batches[0] / 1.6, batches[-1] * 6)      # room for the end labels
        ax.xaxis.set_major_locator(FixedLocator(batches))
        ax.xaxis.set_minor_locator(NullLocator())
        ax.set_xticklabels([f"{b:,}" for b in batches])
        ax.set_xlabel("stories written at once")
        ax.legend(frameon=False, fontsize=8.5, loc="upper left")
    ax_t.set_yscale("log")
    ax_t.yaxis.set_major_locator(LogLocator(base=10, subs=(1, 2, 5)))   # 100, 200, 500, 1000, ...
    ax_t.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:,.0f}"))
    ax_t.yaxis.set_minor_locator(NullLocator())
    ax_t.set_ylabel("new tokens per second (log)")
    ax_t.set_title(title, loc="left", fontsize=11, weight="bold")
    ax_s.set_ylim(bottom=0)
    ax_s.set_ylabel("time of one step (ms)")
    has_gpu = any(not k.lower().startswith("cpu") for k in rows)
    ax_s.set_title("...because a GPU step costs about the same" if has_gpu else "The time of one step",
                   loc="left", fontsize=11, weight="bold")
    plt.tight_layout()
    plt.show()


# ═══════════════════════════════════════════════════════════════════════════════
# 9. SCOREBOARD — every measurement, per device, compared across machines
# ═══════════════════════════════════════════════════════════════════════════════
#
# A notebook run measures the machine it runs on.  To compare a laptop with a
# GH200, the numbers from each have to meet somewhere: every stage records what it
# measured, and `Scoreboard.save` writes one JSON file per device into results/.
# Run the notebook on a laptop, copy its results/*.json next to the notebook on
# Santis, and both machines appear in the same charts.  Nothing in results/ is typed
# by hand.

RESULTS_SCHEMA = 1

# key -> (what it is, unit, higher is better)
METRICS = {
    "train_tok_s": ("Training: best configuration found", "tok/s", True),
    "gen_tok_s_b1": ("Generation, batch 1, KV cache", "tok/s", True),
    "gen_tok_s_batched": ("Generation, best batch size, KV cache", "tok/s", True),
    "gen_best_batch": ("Batch size of that best generation rate", "seqs", True),
    "run_minutes": ("Training budget", "min", True),
    "run_tokens": ("Tokens trained on within the budget", "tokens", True),
    "run_val_loss": ("Validation loss at the end of the budget", "nats", False),
}

# The whole project as fixed amounts of work.  Each device's time for a stage is
# that amount divided by the rate MEASURED on that device -- nothing else enters.
PROJECT_WORK = [
    # (stage, work, rate key, unit of work, short name for table headers)
    ("Pre-train: CS336's reference budget (328M tokens)", 328e6, "train_tok_s", "tokens", "pre-train"),
    ("Generate 10,000 stories of 200 tokens", 2e6, "gen_tok_s_batched", "tokens", "generate"),
]


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:60]


def device_label(hw: Hardware, kind: str) -> str:
    """'CPU · <model> (N cores)' or 'GPU · <model>' -- the label every chart uses."""
    if kind == "cpu":
        return f"CPU · {hw.cpu_name or hw.name} ({hw.n_cores} cores)"
    return f"GPU · {hw.name}"


class Scoreboard:
    """Collects this session's measurements, one entry per device (CPU, GPU)."""

    def __init__(self, hw: Hardware, source: str = "notebook"):
        self.hw = hw
        self.source = source
        self.entries: dict[str, dict] = {}

    def _entry(self, kind: str) -> dict:
        if kind not in self.entries:
            hw = self.hw
            self.entries[kind] = {
                "schema": RESULTS_SCHEMA,
                "label": device_label(hw, kind),
                "kind": kind,
                "cpu": f"{hw.cpu_name or hw.name} ({hw.n_cores} cores)",
                "gpu": hw.name if kind == "cuda" else None,
                "hbm_gb": hw.hbm_gb if kind == "cuda" else None,
                "host": platform.node(),
                "source": self.source,
                "created": time.strftime("%Y-%m-%d %H:%M"),
                "torch": torch.__version__,
                "cuda": torch.version.cuda,
                "metrics": {},
                "notes": {},
            }
        return self.entries[kind]

    def record(self, kind: str, key: str, value) -> None:
        """Store one measured number.  `kind` is "cpu" or "cuda"."""
        assert key in METRICS, f"unknown metric {key!r} -- add it to METRICS first"
        if value is None or (isinstance(value, float) and not math.isfinite(value)):
            return
        self._entry(kind)["metrics"][key] = float(value)

    def note(self, kind: str, key: str, text: str) -> None:
        """Store a piece of text -- a generated story, a configuration."""
        self._entry(kind)["notes"][key] = text

    def save(self, directory="results") -> list:
        from pathlib import Path

        d = Path(directory)
        d.mkdir(parents=True, exist_ok=True)
        paths = []
        for e in self.entries.values():
            e["created"] = time.strftime("%Y-%m-%d %H:%M")
            p = d / f"{_slug(e['label'])}__{e['source']}.json"
            p.write_text(json.dumps(e, indent=1))
            paths.append(p)
        return paths

    def collect(self, directory="results") -> list[dict]:
        """This session's entries first, then every other results file on disk."""
        mine = list(self.entries.values())
        seen = {(e["label"], e["source"]) for e in mine}
        return mine + [e for e in load_results(directory) if (e["label"], e["source"]) not in seen]


def load_results(directory="results") -> list[dict]:
    """Every results file in `directory`, oldest schema checks included."""
    from pathlib import Path

    out = []
    for p in sorted(Path(directory).glob("*.json")):
        try:
            e = json.loads(p.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        if e.get("schema") == RESULTS_SCHEMA and "metrics" in e:
            e["_file"] = p.name
            out.append(e)
    return out


def _host_cpu_rate(entry: dict, entries: list[dict], key: str):
    """A GPU entry has no tokeniser rate of its own: tokenising is a CPU job, done by
    the host CPU of the same machine.  Find that CPU's entry and use its number."""
    if key in entry["metrics"]:
        return entry["metrics"][key]
    for e in entries:
        if e["kind"] == "cpu" and e["cpu"] == entry["cpu"] and key in e["metrics"]:
            return e["metrics"][key]
    return None


def project_hours(entry: dict, entries: list[dict]) -> dict:
    """Hours for each stage of PROJECT_WORK on this device, from its measured rates."""
    out = {}
    for stage, work, key, *_ in PROJECT_WORK:
        rate = _host_cpu_rate(entry, entries, key)
        out[stage] = work / rate / 3600 if rate else None
    return out


def entry_name(e: dict) -> str:
    """A device's label plus where the numbers came from, so that the same machine
    measured in two sessions shows up as two distinguishable rows."""
    return f"{e['label']} · {'this session' if '_file' not in e else e['source']}"


def human_time(hours) -> str:
    if hours is None:
        return "—"
    s = hours * 3600
    if s < 90:
        return f"{s:.0f} s"
    if hours < 1.5:
        return f"{s/60:.0f} min"
    if hours < 48:
        return f"{hours:.1f} h"
    if hours < 24 * 365:
        return f"{hours/24:.1f} days"
    return f"{hours/24/365:.1f} years"


def _fmt(key: str, v) -> str:
    if v is None:
        return "—"
    unit = METRICS[key][1]
    if unit == "%":
        return f"{v*100:.1f}%"
    if unit in ("tok/s", "tokens", "seqs"):
        return f"{v:,.0f}"
    if unit in ("s", "ms", "TFLOP/s", "MB/s", "min"):
        return f"{v:,.1f}" if v < 100 else f"{v:,.0f}"
    return f"{v:,.2f}" if isinstance(v, float) and v < 100 else f"{v:,.0f}"


def scoreboard_table(entries: list[dict], keys: Sequence[str] | None = None) -> str:
    """Plain-text table: one column per device, one row per metric measured anywhere."""
    keys = keys or [k for k in METRICS if any(k in e["metrics"] for e in entries)]
    names = [f"[{i+1}]" for i in range(len(entries))]
    lines = []
    for i, e in enumerate(entries):
        lines.append(f"  [{i+1}] {e['label']}   ({e['source']}, {e['created']}"
                     + (", this session" if "_file" not in e else f", {e['_file']}") + ")")
    w = max(14, max(len(_fmt(k, e['metrics'].get(k))) for k in keys for e in entries) + 2) if keys else 14
    lines.append("")
    lines.append(f"  {'':<60}" + "".join(f"{n:>{w}}" for n in names))
    lines.append("  " + "─" * (60 + w * len(entries)))
    for k in keys:
        label = f"{METRICS[k][0]} ({METRICS[k][1]})"
        lines.append(f"  {label[:60]:<60}" + "".join(f"{_fmt(k, e['metrics'].get(k)):>{w}}"
                                                     for e in entries))
    return "\n".join(lines)


def plot_scoreboard(entries: list[dict]):
    """Two panels, one bar per device, log scale: training speed and writing speed.

    Colour says which kind of chip a number came from -- GRAY for CPUs, PURPLE for
    GPUs -- and nothing else.  Every bar carries its value, and the fastest device
    in each panel its multiple over the slowest.
    """
    import matplotlib.pyplot as plt

    panels = [("train_tok_s", "Training speed", "tokens / s"),
              ("gen_tok_s_batched", "Writing speed, best number of stories at once", "tokens / s")]
    panels = [p for p in panels if any(p[0] in e["metrics"] for e in entries)]
    if not panels:
        print("  nothing to plot yet")
        return
    labels = [entry_name(e).replace(" · ", "\n", 1) for e in entries]
    fig, axes = plt.subplots(len(panels), 1, figsize=(8.8, 1.0 + 0.42 * len(entries) * len(panels) + 0.5 * len(panels)))
    axes = np.atleast_1d(axes)
    for ax, (key, title, unit) in zip(axes, panels):
        vals = [e["metrics"].get(key) for e in entries]
        idx = [i for i, v in enumerate(vals) if v]
        ys = list(range(len(idx)))
        ax.barh(ys, [vals[i] for i in idx], height=0.62,
                color=[GRAY if entries[i]["kind"] == "cpu" else PURPLE for i in idx])
        ax.set_yticks(ys, [labels[i] for i in idx], fontsize=7.5)
        ax.invert_yaxis()
        ax.set_xscale("log")
        lo = min(vals[i] for i in idx)
        for y, i in zip(ys, idx):
            ax.text(vals[i] * 1.12, y, f"{_fmt(key, vals[i])}   ({vals[i]/lo:,.0f}x)"
                    if vals[i] / lo >= 1.5 else _fmt(key, vals[i]), va="center", fontsize=8)
        hi = max(vals[i] for i in idx)
        ax.set_xlim(lo / 2, hi * 30)
        ax.set_title(f"{title}  ({unit}, log scale)", loc="left", fontsize=10, weight="bold")
        ax.grid(axis="y", alpha=0)
    plt.tight_layout()
    plt.show()


# ═══════════════════════════════════════════════════════════════════════════════
# 10. DATA — find data/, or rebuild it from the public TinyStories release
# ═══════════════════════════════════════════════════════════════════════════════
#
# TinyStories V2 (GPT-4 generated), Eldan & Li 2023, arXiv:2305.07759, licence
# CDLA-Sharing-1.0 per the dataset card.  The four files the notebook needs are cut
# from it deterministically, so a rebuild reproduces them exactly:
#   tinystories_sample.txt  the first 2 MB of the validation split
#   tokenizer_10k.json      train_bpe_fast on the whole validation split, 10,000 tokens:
#                           the tokeniser of the 09:00 lecture, ID for ID
#   train_tokens.npy        the first 200 MB of the training split, encoded, uint16
#   valid_tokens.npy        the first 10 MB of the validation split, encoded, uint16
# Every slice is cut back to the last <|endoftext|>, so no story is split in two.

HF_BASE = "https://huggingface.co/datasets/roneneldan/TinyStories/resolve/main/"
DATA_FILES = ["tinystories_sample.txt", "tokenizer_10k.json", "train_tokens.npy", "valid_tokens.npy"]
SLIDE_IDS = [427, 437, 259, 396]     # "Once upon a time" on the 09:00 slides


def _download(url: str, path, max_bytes: int | None = None) -> None:
    """Download `url` to `path`, or only its first `max_bytes` (an HTTP Range request),
    so that 200 MB of the 2.2 GB training split costs 200 MB of transfer."""
    import urllib.request

    req = urllib.request.Request(url)
    if max_bytes:
        req.add_header("Range", f"bytes=0-{max_bytes - 1}")
    print(f"  downloading {url}" + (f" (first {max_bytes/1e6:.0f} MB)" if max_bytes else ""))
    with urllib.request.urlopen(req) as r, open(path, "wb") as f:
        while chunk := r.read(1 << 22):
            f.write(chunk)


def _read_prefix(path, megabytes: float | None) -> str:
    """The first N million characters of a file (all of it for None), cut back to the
    last story boundary."""
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read() if megabytes is None else f.read(int(megabytes * 1_000_000))
    cut = text.rfind(END_OF_TEXT)
    return text[: cut + len(END_OF_TEXT)] if cut > 0 else text


def ensure_data(directory="data", train_mb: float = 200.0, valid_mb: float = 10.0,
                sample_mb: float = 2.0, tokenizer_mb: float | None = None,
                vocab_size: int = 10_000):
    """Return a directory holding all four data files, building it if necessary.

    Looks in `directory`, `../directory` and `$SCRATCH/cx-llms/data` first.  A
    directory counts only if it holds ALL four files: a half-populated one would fail
    four cells later, somewhere confusing.  Otherwise downloads the public release
    (~230 MB) into `directory`, builds the four files and deletes the raw text.
    A one-off of a few minutes.
    """
    from pathlib import Path

    d = Path(directory)
    for cand in (d, Path("..") / d, Path(os.environ.get("SCRATCH", "/nonexistent")) / "cx-llms" / "data"):
        if all((cand / f).exists() for f in DATA_FILES):
            # The 09:00 slides print these IDs for "Once upon a time"; an older data/
            # built with a different tokeniser is rebuilt rather than silently used.
            if Tokenizer.load(cand / "tokenizer_10k.json").encode("Once upon a time") == SLIDE_IDS:
                return cand
            print(f"{cand}/ holds an older tokeniser than the lecture's -- rebuilding it")
            d = cand
            break

    print(f"data files not found -- rebuilding them in {d}/ from the public TinyStories release")
    d.mkdir(parents=True, exist_ok=True)
    valid_raw, train_raw = d / "TinyStoriesV2-GPT4-valid.txt", d / "TinyStoriesV2-GPT4-train.txt"
    try:
        if not valid_raw.exists():
            _download(HF_BASE + valid_raw.name, valid_raw)
        if not train_raw.exists():
            # characters are at least one byte each, so a little more than train_mb of
            # bytes always holds train_mb million characters
            _download(HF_BASE + train_raw.name, train_raw, int(train_mb * 1.05e6) + 1_000_000)
    except OSError as exc:
        raise SystemExit(f"Could not download TinyStories ({exc}). Copy the data/ folder of "
                         "the exercise next to this notebook instead.")

    workers = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 1)
    (d / "tinystories_sample.txt").write_text(_read_prefix(valid_raw, sample_mb), encoding="utf-8")
    print(f"  training the reference tokeniser ({vocab_size:,} tokens) on the validation split")
    vocab, merges = train_bpe_fast(_read_prefix(valid_raw, tokenizer_mb), vocab_size)
    tok = Tokenizer(vocab, merges)
    tok.save(d / "tokenizer_10k.json")
    for split, raw, mb in (("train", train_raw, train_mb), ("valid", valid_raw, valid_mb)):
        ids, secs = encode_corpus(tok, _read_prefix(raw, mb), n_workers=workers)
        np.save(d / f"{split}_tokens.npy", ids)
        print(f"  {split}: {ids.size/1e6:.1f}M tokens in {secs:.0f}s on {workers} cores")
    valid_raw.unlink()
    train_raw.unlink()
    return d
