"""Plumbing for the bonus of cx_SFT_LoRA (LoRA against full fine-tuning on Qwen2.5-0.5B): packages are installed by
the notebook's setup cell, everything else (device, seed, sizes, result cache, quizzes, model loading, grading)
lives here so the notebook shows only the code that teaches something. `from cx_SFT_LoRA_setup import *` in the notebook.
It must sit in the same folder as the notebook."""
import gc, json, math, os, re, sys, time, random, sqlite3, uuid, importlib.metadata as md
import numpy as np, pandas as pd, matplotlib, matplotlib.pyplot as plt
import torch, torch.nn as nn
from IPython.display import display, HTML

# ── progress bars as text ─────────────────────────────────────────────────────
# Inside a kernel tqdm.auto picks its widget flavour, which needs the ipywidgets extension of the JupyterLab
# that serves the notebook. Not every hub ships it, and without it a bar prints its first line and never moves.
# Text bars need nothing; they go to stdout so JupyterLab does not paint them in the colour of an error.
# huggingface_hub, datasets and transformers bind tqdm.auto.tqdm when imported, so this must come before them.
import tqdm, tqdm.std, tqdm.auto, tqdm.autonotebook

class _text_tqdm(tqdm.std.tqdm):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("file", sys.stdout)
        super().__init__(*args, **kwargs)

tqdm.auto.tqdm = tqdm.autonotebook.tqdm = _text_tqdm
tqdm.auto.trange = tqdm.autonotebook.trange = lambda *args, **kwargs: _text_tqdm(range(*args), **kwargs)

from transformers import AutoTokenizer, AutoModelForCausalLM
from transformers.utils import logging as hf_logging
import transformers, peft
from peft import LoraConfig, get_peft_model, PeftModel
from datasets import load_dataset
import sqlglot
from sqlglot import exp
hf_logging.set_verbosity_error()
stale = transformers.__version__ != md.version("transformers")   # imported before the upgrade landed

# ── device, seed ──────────────────────────────────────────────────────────────
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
ON_GPU = DEVICE == "cuda"
SEED   = 0

def seed_everything(seed=SEED):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if ON_GPU:
        torch.cuda.manual_seed_all(seed)

def free():
    """Call after deleting a model: gives its memory back to the GPU before the next run."""
    gc.collect()
    if ON_GPU:
        torch.cuda.empty_cache()

def clean_axes(ax):
    ax.spines[["top", "right"]].set_visible(False)

# ── counting helpers ────────────────────────────────────────────────────────────
def count_parameters(model):
    return sum(p.numel() for p in model.parameters())

def count_trainable(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def training_state_bytes(n_total, n_trainable, bytes_per_param=4):
    """Weights for every parameter; a gradient and two Adam moments for every trainable one."""
    return bytes_per_param * (n_total + 3 * n_trainable)

def fmt_bytes(n):
    """Decimal units: 1 KB = 1000 B, 1 MB = 10^6 B, 1 GB = 10^9 B."""
    for unit, div in (("GB", 1e9), ("MB", 1e6), ("KB", 1e3)):
        if n >= div:
            return "%.2f %s" % (n / div, unit)
    return "%d B" % n

# ── quizzes: plain HTML, graded by a few lines of JavaScript in the browser ────
# ipywidgets would need the extension mentioned above. This needs nothing: the cell's output is HTML the
# reader produced, so JupyterLab trusts it and runs its script. Statements and keys stay in this file, not
# in the notebook cell that shows the quiz, because that cell is open and would show its own answers.
from string import Template as _Template
import html as _html

_CARD = ('<div style="font-family:system-ui,Segoe UI,Roboto,sans-serif;padding:16px 18px;border-radius:18px;'
         'border:1px solid #ecebff;background:linear-gradient(135deg,#f6f8ff,#fbf5ff);color:#2d3142;font-size:14px">'
         '<div style="font-weight:700;margin-bottom:10px">%s</div>%s'
         '<button id="%s-check" style="margin-top:10px;padding:7px 16px;border:none;border-radius:10px;color:white;'
         'font-weight:600;cursor:pointer;background:linear-gradient(135deg,#667eea,#764ba2)">Check</button>'
         '<div id="%s-out" style="margin-top:8px;font-weight:600;white-space:pre-wrap"></div></div>')
_ROW = ('<label style="display:flex;gap:10px;align-items:flex-start;margin:5px 0;line-height:1.4">'
        '<input type="%s" name="%s" id="%s-%d" style="margin-top:4px;accent-color:#667eea"><span>%s</span>'
        '<span id="%s-m%d"></span></label>')

_TF_JS = _Template("""(function () {
  var uid = "$uid", key = $key;
  document.getElementById(uid + "-check").onclick = function () {
    var wrong = 0;
    key.forEach(function (k, i) {
      var ok = document.getElementById(uid + "-" + i).checked === k;
      document.getElementById(uid + "-m" + i).textContent = ok ? "✅" : "❌";
      if (!ok) wrong += 1;
    });
    document.getElementById(uid + "-out").textContent = wrong
      ? "❌ " + wrong + " of " + key.length + " wrong. Reconsider the marked ones."
      : "✅ All " + key.length + " statements classified correctly.";
  };
})();""")

_MC_JS = _Template("""(function () {
  var uid = "$uid", n = $n, answer = $answer, explain = $explain;
  document.getElementById(uid + "-check").onclick = function () {
    var picked = -1;
    for (var i = 0; i < n; i++) if (document.getElementById(uid + "-" + i).checked) picked = i;
    document.getElementById(uid + "-out").textContent = picked < 0 ? "Pick an answer first."
      : picked === answer ? "✅ Correct. " + explain : "❌ Not quite. Think again, then try another option.";
  };
})();""")

def _show(title, rows, script, uid):
    display(HTML(_CARD % (title, "".join(rows), uid, uid) + "<script>" + script + "</script>"))

def tf_quiz(statements):
    """statements: list of (text, is_true). Tick the true ones, press Check: every row is marked, the tally below."""
    uid = "quiz-" + uuid.uuid4().hex[:8]
    rows = [_ROW % ("checkbox", uid, uid, i, _html.escape(text), uid, i) for i, (text, _) in enumerate(statements)]
    key = json.dumps([bool(is_true) for _, is_true in statements])
    _show("Tick every statement that is true.", rows, _TF_JS.substitute(uid=uid, key=key), uid)

def mc_quiz(question, options, answer, explain):
    """One right option among several: answer is its index, explain is printed when it is picked."""
    uid = "quiz-" + uuid.uuid4().hex[:8]
    rows = [_ROW % ("radio", uid, uid, i, _html.escape(option), uid, i) for i, option in enumerate(options)]
    _show(_html.escape(question), rows, _MC_JS.substitute(uid=uid, n=len(options), answer=int(answer),
                                                          explain=json.dumps(explain)), uid)

def quiz_lora_costs():
    """The quiz of "Your turn: read the cost table"."""
    tf_quiz([
        ("LoRA trained under 2% of the parameters.", True),
        ("The LoRA checkpoint (A and B) is a few tens of MB; a full fine-tune checkpoint is a whole copy of the model, about 1 GB.", True),
        ("LoRA also used under 2% of the GPU memory of full fine-tuning.", False),
        ("During LoRA training the frozen weights still have to sit on the GPU.", True),
        ("The activations saved for the backward pass get smaller when fewer parameters are trainable.", False),
        ("What LoRA removes from GPU memory is the gradients and the Adam moments of the frozen parameters.", True),
        ("LoRA training was much faster, because most parameters are frozen.", False),
        ("The bigger the model, the bigger LoRA's memory saving, because gradients and Adam state grow with the parameter count, while the activations grow more slowly.", True),
        ("A LoRA adapter can overwrite the pretrained weights.", False),
    ])

def quiz_final():
    """The flash quiz that closes the notebook."""
    tf_quiz([
        ("A frozen parameter is still used in the forward pass.", True),
        ("A frozen parameter needs no gradient and no Adam state, so it costs less training memory.", True),
        ("LoRA changes the pretrained matrix W directly.", False),
        ("LoRA trains two small matrices A and B next to a frozen W.", True),
        ("A larger rank r means more trainable parameters.", True),
        ("LoRA roughly halves training time, because most parameters are frozen.", False),
        ("Remove the LoRA adapter and you get the pretrained model back, exactly.", True),
        ("Training every parameter at the learning rate that suits LoRA can destroy a pretrained model.", True),
    ])

def section(title, body):
    print(f"── {title} " + "─" * (60 - len(title)))
    print(body.rstrip())
    print()

# ── sizes: one budget shared by every run ─────────────────────────────────────
TRAIN_N   = 2_000    # training examples, the same ones for every run
EVAL_N    = 200      # held-out questions every run is graded on
EPOCHS    = 2
MMLU_N    = 120      # multiple-choice questions, for forgetting
PPL_DOCS  = 100      # WikiText documents, for forgetting

BATCH_SIZE      = 8      # examples per forward pass: what the GPU holds at once
EFFECTIVE_BATCH = 32     # examples per optimiser step: several forward passes are accumulated into one update
MAX_LEN         = 320    # longest input the grading passes tokenise; every SQL transcript is far shorter
MAX_NEW_TOKENS  = 64     # the longest reference query is far shorter

# ── the result cache: a fixed path, so a restarted notebook finds finished runs ─
# On a cluster the home directory is small and the notebook is served from it: write the 1 GB checkpoints
# to $SCRATCH when it exists (set on CSCS Alps), otherwise next to the notebook, as on Colab.
_user       = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
_scratch    = os.environ.get("SCRATCH") or (os.path.join("/capstor/scratch/cscs", _user) if _user else "")
_writable   = bool(_scratch) and os.path.isdir(_scratch) and os.access(_scratch, os.W_OK)
CKPT_DIR    = os.path.abspath(os.path.join(_scratch if _writable else ".", "peft_llm_runs"))
RESULTS_DIR = os.path.join(CKPT_DIR, "results")
WEIGHTS_DIR = os.path.join(CKPT_DIR, "weights")      # the two models "Your turn: test the three models" talks to
os.makedirs(RESULTS_DIR, exist_ok=True); os.makedirs(WEIGHTS_DIR, exist_ok=True)

def load_result(name):
    path = os.path.join(RESULTS_DIR, name + ".json")
    return json.load(open(path)) if os.path.exists(path) else None

def save_result(name, record):
    json.dump(record, open(os.path.join(RESULTS_DIR, name + ".json"), "w"), indent=1)
    return record

# ── training plumbing, so the training loop itself stays readable ─────────────
def start_training(model):
    """Gradient checkpointing (recompute activations instead of storing them), a fresh memory counter, train mode."""
    try:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    except TypeError:                                    # older transformers
        model.gradient_checkpointing_enable()
    model.enable_input_require_grads(); model.config.use_cache = False; model.train()
    if ON_GPU:
        torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats()
    return time.perf_counter()

def finish_training(model, t0):
    """Back to inference mode. Returns (minutes of wall-clock, peak GPU memory in GB)."""
    model.gradient_checkpointing_disable(); model.eval(); model.config.use_cache = True
    return (time.perf_counter() - t0) / 60, (torch.cuda.max_memory_allocated() / 1e9 if ON_GPU else None)

# ── the model ─────────────────────────────────────────────────────────────────
def silence_unusable_backends():
    """peft probes every optional quantisation backend when it wraps a layer. A probe RAISES when its
    package is installed but too old; such a backend is marked "not available" instead."""
    import peft.import_utils as probes
    off = []
    for name in dir(probes):
        probe = getattr(probes, name)
        if not (name.startswith("is_") and name.endswith("_available") and callable(probe)):
            continue
        try:
            probe()
        except ImportError:
            for module in list(sys.modules.values()):
                if getattr(module, "__name__", "").startswith("peft") and getattr(module, name, None) is probe:
                    setattr(module, name, lambda *a, **k: False)
            off.append(name)
        except Exception:
            pass
    return off

MODEL_NAME = "Qwen/Qwen2.5-0.5B"        # the base model, not the Instruct one
DTYPE = torch.bfloat16 if (ON_GPU and torch.cuda.is_bf16_supported()) else torch.float32

def load_backbone(name=MODEL_NAME, dtype=DTYPE):
    """The weights in `dtype`: the run-wide DTYPE unless the caller asks for another (full fine-tuning wants float32)."""
    try:
        model = AutoModelForCausalLM.from_pretrained(name, dtype=dtype, attn_implementation="sdpa")
    except TypeError:                                    # transformers < 4.56 spells it torch_dtype
        model = AutoModelForCausalLM.from_pretrained(name, torch_dtype=dtype, attn_implementation="sdpa")
    return model.to(DEVICE).eval()

disabled = silence_unusable_backends()
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
if tokenizer.pad_token_id is None:
    tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "left"          # batched generation: every prompt must end at the last position
seed_everything()
llm   = load_backbone()
cfg   = llm.config
N_LLM = count_parameters(llm)

# ── grading: SQL syntax, SQL accuracy (same data), MMLU, WikiText perplexity ────
def parses(sql):
    try:
        sqlglot.parse_one(sql, dialect="sqlite"); return True
    except Exception:
        return False

def _schema(context):
    """[(table, [(column, type)])] from the CREATE TABLE statements of one example."""
    tables = []
    for statement in filter(str.strip, context.split(";")):
        try:
            tree = sqlglot.parse_one(statement, dialect="sqlite")
        except Exception:
            continue
        if isinstance(tree, exp.Create):
            tables.append((tree.this.this.name, [(c.this.name, (c.kind.sql() if c.kind else "VARCHAR").upper())
                                                 for c in tree.this.expressions if isinstance(c, exp.ColumnDef)]))
    return tables

def _database(context, reference, seed, n_rows=8):
    """An in-memory SQLite database for one example, filled with rows that straddle the values the reference
    query compares against. This dataset double-quotes its strings, so they are read straight off the text."""
    tables = _schema(context)
    known = {c for _, cols in tables for c, _ in cols} | {t for t, _ in tables}
    strings = [s for s in (a or b for a, b in re.findall(r'"([^"]*)"|\'([^\']*)\'', reference)) if s and s not in known]
    numbers = [int(float(x)) for x in re.findall(r"(?<![\w.])(-?\d+(?:\.\d+)?)(?![\w.])", reference)]
    con, rng = sqlite3.connect(":memory:"), random.Random(seed)
    for table, cols in tables:
        con.execute("CREATE TABLE IF NOT EXISTS %s (%s)" % (table, ", ".join("%s %s" % c for c in cols)))
        pools = [sorted({1, 2, 3} | {v + d for v in numbers for d in (-1, 0, 1)})
                 if any(k in kind for k in ("INT", "REAL", "DEC", "NUM")) else list(dict.fromkeys(strings + ["a", "b", "c"]))
                 for _, kind in cols]
        for _ in range(n_rows):
            con.execute("INSERT INTO %s VALUES (%s)" % (table, ", ".join("?" * len(cols))), [rng.choice(pool) for pool in pools])
    return con

def _rows(con, query):
    try:
        return sorted(str(r) for r in con.execute(query).fetchall())
    except Exception:
        return None                     # does not run: not the same data by any reading

def same_data(pred, ref, context, seeds=(0, 1, 2)):
    """(equal, decidable): does pred return the same rows as ref on three invented databases?
    Undecidable when the reference returns nothing on all of them, since then every query looks alike."""
    equal, decidable = True, False
    for seed in seeds:
        try:
            con = _database(context, ref, seed)
        except Exception:
            return None, False
        gold = _rows(con, ref)
        if gold is None:
            return None, False
        decidable |= any(r not in ("(0,)", "(None,)") for r in gold)
        equal &= _rows(con, pred) == gold
    return equal, decidable

def execution_match(preds, refs, contexts):
    verdicts = [same_data(p, r, c) for p, r, c in zip(preds, refs, contexts)]
    usable = [eq for eq, ok in verdicts if ok and eq is not None]
    return (float(np.mean(usable)) if usable else float("nan")), len(usable)

_ref, _ctx = "SELECT name FROM head WHERE age > 56", "CREATE TABLE head (age INTEGER, name VARCHAR)"
assert same_data("SELECT h.name FROM head AS h WHERE h.age > 56", _ref, _ctx)[0]      # an alias is not a mistake
assert not same_data("SELECT name FROM head", _ref, _ctx)[0]                          # the filter matters
assert same_data('SELECT venue FROM game WHERE away_team = "essendon"', 'SELECT venue FROM game WHERE away_team = "essendon"',
                 "CREATE TABLE game (venue VARCHAR, away_team VARCHAR)") == (True, True)   # double-quoted values reach the rows

EMPTY, TRUNCATED = "[EMPTY]", "[TRUNCATED]"        # how every cell in this notebook marks a reply that is blank / never stopped

def mark(text, stopped):
    """Standard rendering of one reply: blank -> [EMPTY]; ran out of tokens -> text + [TRUNCATED]."""
    text = text.strip()
    return EMPTY if not text else (text if stopped else text + " " + TRUNCATED)

@torch.no_grad()
def generate(model, prompts, max_new_tokens=MAX_NEW_TOKENS, batch_size=16, marked=False):
    """Greedy decoding in batches. Prompts are padded on the LEFT so they all end at the same position.
    marked=True renders each reply with mark(); the SQL grading needs the raw text instead."""
    model.eval(); out = []
    for i in range(0, len(prompts), batch_size):
        enc = tokenizer(prompts[i:i + batch_size], return_tensors="pt", padding=True, truncation=True, max_length=MAX_LEN).to(DEVICE)
        ids = model.generate(**enc, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.pad_token_id)
        new = ids[:, enc["input_ids"].shape[1]:]
        for row, text in zip(new, tokenizer.batch_decode(new, skip_special_tokens=True)):
            out.append(mark(text, stopped=bool((row == tokenizer.eos_token_id).any())) if marked else text)
    return out

@torch.no_grad()
def say(model, text, max_new_tokens=100):
    """Greedy continuation of one prompt. This is all "generation" is."""
    model.eval()
    ids = tokenizer(text, return_tensors="pt").to(DEVICE)
    out = model.generate(**ids, max_new_tokens=max_new_tokens, do_sample=False,
                         pad_token_id=tokenizer.pad_token_id)
    new = out[0, ids["input_ids"].shape[1]:]
    return mark(tokenizer.decode(new, skip_special_tokens=True), stopped=bool((new == tokenizer.eos_token_id).any()))

mmlu_rows  = [row for row in load_dataset("cais/mmlu", "all", split="test").shuffle(seed=SEED).select(range(MMLU_N))]
wiki_docs  = [t for t in load_dataset("Salesforce/wikitext", "wikitext-2-raw-v1", split="test")["text"] if len(t.strip()) > 200][:PPL_DOCS]
LETTER_IDS = [tokenizer(" " + l, add_special_tokens=False)["input_ids"][0] for l in "ABCD"]

def mmlu_prompt(row):
    return "%s\n%s\nAnswer:" % (row["question"], "\n".join("%s. %s" % (l, c) for l, c in zip("ABCD", row["choices"])))

@torch.no_grad()
def mmlu_acc(model, batch_size=8):
    """One forward pass per question: which of A B C D is the most likely next token."""
    model.eval(); correct = 0
    for i in range(0, len(mmlu_rows), batch_size):
        chunk = mmlu_rows[i:i + batch_size]
        enc = tokenizer([mmlu_prompt(r) for r in chunk], return_tensors="pt", padding=True, truncation=True, max_length=MAX_LEN).to(DEVICE)
        picked = model(**enc).logits[:, -1, LETTER_IDS].argmax(dim=-1).tolist()
        correct += sum(p == r["answer"] for p, r in zip(picked, chunk))
    return correct / len(mmlu_rows)

@torch.no_grad()
def wikitext_ppl(model):
    """Perplexity on plain English prose: how surprised the model is by ordinary text."""
    model.eval(); nll, count = 0.0, 0
    for doc in wiki_docs:
        ids = tokenizer(doc, return_tensors="pt", truncation=True, max_length=512).to(DEVICE)
        n = ids["input_ids"].shape[1]
        nll += model(**ids, labels=ids["input_ids"]).loss.float().item() * (n - 1); count += n - 1
    return float(np.exp(nll / count))

OOD_PROMPTS = ["What is the capital of France?", "Write a haiku about the sea", "Here there is a description of what is SQL:",
               "2+2=", "Translate 'good morning' to Italian."]

LOADED = {}                                   # a saved model is read from disk once, then kept

def saved_model(run):
    """The model behind one cached run: the backbone for the baseline, otherwise its saved weights (None if never saved)."""
    if run == "baseline":
        return llm
    if run not in LOADED:
        path = os.path.join(WEIGHTS_DIR, run)
        if not os.path.exists(path):
            return None
        LOADED[run] = (PeftModel.from_pretrained(load_backbone(), path).eval() if run.startswith("lora") else load_backbone(path))
    return LOADED[run]

PROMPT = "-- Schema:\n{context}\n-- Question: {question}\n-- SQL:\n"     # the one template, for training and grading alike

def evaluate(model, test_rows):
    """Every metric for one model on the given test rows: SQL syntax, SQL accuracy, MMLU, perplexity, and five ordinary prompts."""
    preds = [t.strip().split("\n")[0].strip() for t in generate(model, [PROMPT.format(**r) for r in test_rows])]  # first line: a base model keeps talking
    refs, contexts = [r["answer"] for r in test_rows], [r["context"] for r in test_rows]
    rate, decidable = execution_match(preds, refs, contexts)
    return {"syntax": float(np.mean([parses(p) for p in preds])),          # 1. does it parse as SQL?
            "same_data": rate, "decidable": decidable,                       # 2. does it return the same rows as the reference?
            "mmlu": mmlu_acc(model), "ppl": wikitext_ppl(model),             # 3. and 4. what did the training cost elsewhere?
            "preds": preds, "sample": preds[:3],
            "ood": [t.replace("\n", " ")[:80] for t in generate(model, OOD_PROMPTS, max_new_tokens=40, marked=True)],
            "ood_prompts": list(OOD_PROMPTS)}                                    # so a later prompt change is noticed

# ── cached results that predate a change, and the comparison plot ─────────────
def refresh_ood(records):
    """A run graded on an older list of ordinary prompts is asked the current five again, if its weights were saved."""
    for x in records:
        if x.get("ood_prompts") != list(OOD_PROMPTS):
            model = saved_model(x["run"])
            if model is None:
                continue
            x["ood"] = [t.replace("\n", " ")[:80] for t in generate(model, OOD_PROMPTS, max_new_tokens=40, marked=True)]
            x["ood_prompts"] = list(OOD_PROMPTS)
            save_result(x["run"], {k: v for k, v in x.items() if k != "label"})

def plot_metrics(records):
    """One panel per metric, one bar per model."""
    colours = ["#898781", "#2a78d6", "#eb6834"]                 # base model (reference), LoRA, full fine-tuning
    labels  = [x["label"] for x in records]
    panels  = [("SQL syntax  ↑",            [100 * x["syntax"]    for x in records], "%"),
               ("SQL accuracy  ↑",          [100 * x["same_data"] for x in records], "%"),
               ("MMLU  ↑",                  [100 * x["mmlu"]      for x in records], "%"),
               ("WikiText perplexity  ↓",   [x["ppl"]             for x in records], "log")]

    fig, axes = plt.subplots(1, 4, figsize=(13, 3.6))
    for ax, (title, values, kind) in zip(axes, panels):
        bars = ax.bar(labels, values, width=0.55, color=colours)
        for b, v in zip(bars, values):                              # the number sits on its bar
            ax.text(b.get_x() + b.get_width() / 2, b.get_height(), ("%.0f%%" if kind == "%" else "%.0f") % v,
                    ha="center", va="bottom", fontsize=9, color="#0b0b0b")
        if kind == "%":
            ax.set_ylim(0, 115)
        else:
            ax.set_yscale("log")
            ax.yaxis.set_major_locator(matplotlib.ticker.LogLocator(base=10, subs=(1.0, 2.0, 5.0)))
            ax.yaxis.set_major_formatter(matplotlib.ticker.ScalarFormatter()); ax.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
        ax.set_title(title, fontsize=10, loc="left"); ax.tick_params(axis="x", labelsize=8, rotation=12)
        ax.grid(axis="y", color="#e1e0d9", lw=0.8); ax.set_axisbelow(True); clean_axes(ax)
    plt.tight_layout(); plt.show()

# ── report ────────────────────────────────────────────────────────────────────
def report():
    """What the setup loaded: versions, device, model, sizes."""
    print("transformers %s · peft %s · torch %s · %s%s" % (transformers.__version__, peft.__version__, torch.__version__,
          DEVICE, " (%s)" % torch.cuda.get_device_name(0) if ON_GPU else " (no GPU: this part will be very slow)"))
    if disabled:
        print("peft backends disabled:", ", ".join(disabled))
    print("\n%s · %s parameters · %d blocks · hidden size %d · %s"
          % (type(llm).__name__, format(N_LLM, ","), cfg.num_hidden_layers, cfg.hidden_size, str(DTYPE).replace("torch.", "")))
    print("weights alone                           :", fmt_bytes(N_LLM * (2 if DTYPE != torch.float32 else 4)))
    print("training state if every parameter trains:", fmt_bytes(training_state_bytes(N_LLM, N_LLM)), "(fp32 weights, grads, Adam)")
    print("\nthe seven linear layers of one block:")
    for name, module in llm.model.layers[0].named_modules():
        if isinstance(module, nn.Linear):
            print("   %-10s Linear(%4d → %4d)" % (name, module.in_features, module.out_features))

    steps_per_run = EPOCHS * math.ceil(TRAIN_N / EFFECTIVE_BATCH)
    print("\n2 training runs × %d optimiser steps · each graded on %d SQL questions, %d MMLU questions, %d WikiText documents"
          % (steps_per_run, EVAL_N, MMLU_N, PPL_DOCS))
    print("grading: %d SQL questions · %d MMLU questions · %d WikiText documents" % (EVAL_N, len(mmlu_rows), len(wiki_docs)))
    print("results cached in", CKPT_DIR)
    if stale:
        print("\n/!\\ transformers was already imported in this kernel, so the upgrade is not active yet."
              "\n    Restart the kernel (Kernel -> Restart Kernel...) and run this cell again.")
