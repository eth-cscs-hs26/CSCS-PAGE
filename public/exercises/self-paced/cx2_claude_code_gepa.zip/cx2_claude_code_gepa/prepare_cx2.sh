#!/usr/bin/env bash
# =============================================================================================================
# prepare_cx2.sh — one-time preparation of the "Claude Code & GEPA" exercise on your own CSCS account.
#
# Run it once, in a JupyterLab terminal on Santis (File → New → Terminal), from the exercise folder:
#   bash prepare_cx2.sh
# It fills one folder on your scratch, which the notebook's first cell then reads:
#   $SCRATCH/cx2/bin/ollama   bin/claude   lib/ollama/...   models/
# About 20 GB of downloads (the two models). It needs no GPU and no API key, only the internet access the session has.
# Files on scratch unused for 30 days are deleted: if the notebook later reports a missing model, run this again.
# Another folder: export CX2_SHARED=/some/folder before running it, and in the notebook's environment as well.
# Python packages are not installed here: the notebook pip-installs dspy and pytest --user when they are missing.
# =============================================================================================================
set -euo pipefail
SCRATCH=${SCRATCH:-/capstor/scratch/cscs/$USER}   # set on Alps; the same path if not
CX2_SHARED=${CX2_SHARED:-$SCRATCH/cx2}
AGENT_BASE=${AGENT_BASE:-qwen3-coder:30b}   # drives Claude Code + GEPA reflection. Alternatives: qwen3:30b, gpt-oss:20b
TASK_MODEL=${TASK_MODEL:-qwen2.5:1.5b}      # the small model GEPA optimizes
AGENT_CTX=${AGENT_CTX:-65536}

[ "$(uname -m)" = "aarch64" ] || echo "⚠️  WARNING: this machine is $(uname -m), not aarch64 — binaries/packages won't run on GH200 nodes."
mkdir -p "$CX2_SHARED"/{bin,models}
WORK=$(mktemp -d)                            # private to this run: other users may share the node

echo "== 1/3  Ollama (linux-arm64) -> $CX2_SHARED/bin, lib/"
if [ ! -x "$CX2_SHARED/bin/ollama" ]; then
  base=https://ollama.com/download/ollama-linux-arm64
  if command -v zstd >/dev/null && curl -fsIL "$base.tar.zst" >/dev/null 2>&1; then
    curl -fL "$base.tar.zst" | zstd -d | tar -xf - -C "$CX2_SHARED"
  else
    curl -fL "$base.tgz" | tar -xzf - -C "$CX2_SHARED"
  fi
fi
"$CX2_SHARED/bin/ollama" --version || true

echo "== 2/3  Models -> $CX2_SHARED/models   ($AGENT_BASE ~19 GB, $TASK_MODEL ~1 GB)"
PORT=$(python3 -c 'import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1])')
export OLLAMA_MODELS="$CX2_SHARED/models" OLLAMA_HOST=127.0.0.1:$PORT
"$CX2_SHARED/bin/ollama" serve > "$WORK/ollama.log" 2>&1 &
SERVE_PID=$!; trap 'kill $SERVE_PID 2>/dev/null || true; rm -rf "$WORK"' EXIT
for _ in $(seq 30); do curl -s "http://$OLLAMA_HOST/api/tags" >/dev/null && break; sleep 1; done
curl -s "http://$OLLAMA_HOST/api/tags" >/dev/null || { echo "❌ the Ollama server did not start:"; cat "$WORK/ollama.log"; exit 1; }
"$CX2_SHARED/bin/ollama" pull "$AGENT_BASE"
"$CX2_SHARED/bin/ollama" pull "$TASK_MODEL"
printf 'FROM %s\nPARAMETER num_ctx %s\n' "$AGENT_BASE" "$AGENT_CTX" > "$WORK/cx2_agent.Modelfile"
"$CX2_SHARED/bin/ollama" create cx2-agent -f "$WORK/cx2_agent.Modelfile"
"$CX2_SHARED/bin/ollama" list

echo "== 3/3  Claude Code CLI (native binary) -> $CX2_SHARED/bin/claude"
if [ ! -x "$CX2_SHARED/bin/claude" ]; then
  TMPH="$WORK/home"; mkdir -p "$TMPH"
  HOME="$TMPH" bash -c 'curl -fsSL https://claude.ai/install.sh | bash' > "$WORK/claude.log" 2>&1 || true
  if [ -e "$TMPH/.local/bin/claude" ]; then
    cp -L "$TMPH/.local/bin/claude" "$CX2_SHARED/bin/claude"
  elif command -v npm >/dev/null; then        # fallback: npm package (needs node on the compute nodes too!)
    npm install -g --prefix "$CX2_SHARED/npm" @anthropic-ai/claude-code
    ln -sf "$CX2_SHARED/npm/bin/claude" "$CX2_SHARED/bin/claude"
  else
    echo "❌ Claude Code did not install:"; cat "$WORK/claude.log"; exit 1
  fi
fi
"$CX2_SHARED/bin/claude" --version

echo
echo "✅ Done: $CX2_SHARED holds Ollama, the two models and Claude Code. Open the notebook and run its first cell."
