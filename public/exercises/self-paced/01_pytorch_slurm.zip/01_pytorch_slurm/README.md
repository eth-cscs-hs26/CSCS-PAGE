# CX PyTorch with SLURM and SLT

**CSCS AI Tutorials · Part I, Day 1 · about 45 minutes · on your own CSCS account**

The lecture showed the training and SLURM pipeline. Your task is to submit a working
one-GPU job yourself, prove it ran correctly, then compare two weight-decay settings.
Start with `01_pytorch_slurm_student.ipynb` and follow its sections in order.

This is the self-paced version of the course exercise: it runs on your own CSCS account
and project, not on the course accounts, which closed after the course.

## Before the first job: three one-time steps

1. **Your project in the job script.** Open `submit.sbatch` and replace `<YOUR_PROJECT>`
   in `#SBATCH --account=<YOUR_PROJECT>` with your CSCS project, the account your GPU
   time is charged to (the one you pass to `--account` in your own jobs). The notebook's
   first check stops until you have done so.
2. **The PyTorch uenv.** The job runs `train.py` in the PyTorch uenv of the lecture,
   `pytorch/v2.9.1:v2`, which must be in your own uenv repository. Pull it once, from a
   terminal on a Santis login node, reached over SSH as for your own work:

   ```bash
   uenv image pull pytorch/v2.9.1:v2
   ```

   It takes a few minutes. `uenv image ls` lists what you have. Pulling is light work,
   so the login node is the right place for it; the `uenv` command is not available
   inside the JupyterLab container.
3. **The JupyterLab session.** Start it with the course TOML from the website's
   *On your own* page. That TOML mounts one library, `libjson-c.so.5`, without which
   `sbatch` fails inside JupyterLab.

## Where to work

Keep all the files in this folder together. Open the notebook in the JupyterLab
session for checks, plots and interpretation, and a **JupyterLab terminal** (File → New →
Terminal) for `sbatch`, `squeue` and `sacct`. In that terminal, move into this folder and run
`source cluster-env.sh` once: it gives the Slurm commands a clean environment, so that the
job runs on the compute node and not inside the JupyterLab container again. Google Colab is
not a route to submit CSCS SLURM jobs.

The batch file requests one node, one task and one GPU on the `normal` partition, with a
five-minute limit. The training step is complete. There is no dataset download; `train.py`
creates the samples in memory. The code refuses to train on a login node and checks that
exactly one GPU is visible inside the job.

## Core run sequence

From this folder in the **JupyterLab terminal**:

```bash
source cluster-env.sh
mkdir -p logs
job1=$(sbatch --parsable submit.sbatch 128 0.0)
job1=${job1%%;*}
printf 'Baseline job ID: %s\n' "$job1"
squeue -j "$job1" -o '%.18i %.9T %.10M %.6D %R'
scontrol show job "$job1"
tail -n 20 "logs/cx-pytorch-${job1}.out"
tail -n 20 "logs/cx-pytorch-${job1}.err"
sacct -j "$job1" --format=JobID,State,ExitCode,Elapsed,AllocTRES
```

A job ID proves submission, not completion. A pending job may have no logs. If it stays
pending, read the reason in the last column of `squeue` and wait rather than submitting
copies: on a busy day the queue can take a while. Check both job and training-step
accounting. Look for `COMPLETED`, exit code `0:0`, a `FIRST_STEP` line with five `cuda:0`
devices, and `runs/<JOB_ID>/summary.json`.

After the baseline finishes, write a prediction in the notebook. Keep width 128 and
change only weight decay:

```bash
job2=$(sbatch --parsable submit.sbatch 128 0.01)
job2=${job2%%;*}
printf 'Weight-decay job ID: %s\n' "$job2"
```

Repeat the status, log and accounting checks for `$job2`. Enter both IDs in the notebook,
which checks the saved results and plots the curves. Compare final training and validation
loss and accuracy, then write a short conclusion and limitation. The optional debugging
question needs no additional cluster job.

## If something fails

- `sbatch: error: ... account` or `Invalid account`: the project in `submit.sbatch` is not
  one you belong to; fix the `--account` line.
- An error that mentions `libjson-c.so.5`: the session was not started with the TOML of
  the *On your own* page. Stop the server and start it again with that TOML.
- In `logs/cx-pytorch-<JOB_ID>.err`, an error that the uenv `pytorch/v2.9.1:v2` cannot be
  found: pull it as in step 2 above, then submit again.

## What each job saves

```text
logs/cx-pytorch-<JOB_ID>.out    # epochs, FIRST_STEP devices, completion
logs/cx-pytorch-<JOB_ID>.err    # errors and warnings
runs/<JOB_ID>/config.json      # settings, seeds, host and GPU
runs/<JOB_ID>/metrics.csv      # train/validation metrics for each epoch
runs/<JOB_ID>/summary.json     # written only after successful completion
```

A failed run may have partial files but no summary; keep its logs and submit a new job
after fixing it.
