# Run once in each JupyterLab terminal, from this folder:  source cluster-env.sh
#
# sbatch copies the environment of the shell it runs in into the job. Inside the JupyterLab container that
# environment belongs to the container, and the job would start inside the container again. These wrappers give
# each Slurm command a clean environment, so the job runs on the compute node itself, where srun mounts the uenv.
#
# The Slurm commands also need one library, libjson-c.so.5, that the container image lacks. The course TOML of the
# website's "On your own" page mounts it from the host; a session started with another TOML may not have it.
if [ ! -e /usr/lib64/libjson-c.so.5 ] && [ ! -e /usr/lib/aarch64-linux-gnu/libjson-c.so.5 ]; then
    echo "Warning: libjson-c.so.5 is missing, so sbatch will fail. Start the JupyterLab session with the TOML"
    echo "of the website's 'On your own' page, which mounts it."
fi
# SCRATCH is kept: uenv finds the images you pulled through it.
cx_clean() { env -i HOME="$HOME" USER="$USER" SCRATCH="${SCRATCH:-/capstor/scratch/cscs/$USER}" PATH=/usr/bin:/bin "$@"; }
sbatch()   { cx_clean sbatch "$@"; }
squeue()   { cx_clean squeue "$@"; }
scontrol() { cx_clean scontrol "$@"; }
sacct()    { cx_clean sacct "$@"; }
scancel()  { cx_clean scancel "$@"; }
echo "Slurm commands ready for this terminal."
