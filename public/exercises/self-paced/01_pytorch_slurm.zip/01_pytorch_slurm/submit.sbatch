#!/bin/bash
#SBATCH --job-name=cx-pytorch
#SBATCH --account=<YOUR_PROJECT>
#SBATCH --partition=normal
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gpus-per-task=1
#SBATCH --cpus-per-task=1
#SBATCH --time=00:05:00
#SBATCH --output=logs/%x-%j.out
#SBATCH --error=logs/%x-%j.err

set -euo pipefail
# Create logs/ in the submission directory BEFORE calling sbatch.
: "${SLURM_JOB_ID:?Submit this file with sbatch}"
: "${SLURM_SUBMIT_DIR:?Missing submission directory}"
cd "$SLURM_SUBMIT_DIR"
[[ -f train.py && -f learner.py ]] || { echo "Submit from the exercise directory." >&2; exit 2; }
export OMP_NUM_THREADS=1
export PYTHONUNBUFFERED=1
width="${1:-128}"
weight_decay="${2:-0.0}"
output="runs/${SLURM_JOB_ID}"
echo "job=$SLURM_JOB_ID host=$(hostname) directory=$PWD width=$width weight_decay=$weight_decay"
# The PyTorch uenv of the lecture, mounted by srun on the compute node. Pull it once beforehand (README.md):
#   uenv image pull pytorch/v2.9.1:v2
srun --uenv=pytorch/v2.9.1:v2 --view=default \
    python -u train.py \
    --width "$width" --weight-decay "$weight_decay" --output "$output"
